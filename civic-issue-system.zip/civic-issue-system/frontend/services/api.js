/**
 * API service for making requests to the backend
 */

import { toast } from 'react-hot-toast';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

/**
 * Handles API errors and displays toast notifications
 * @param {Error} error - The error object
 * @returns {Object} - The error response
 */
const handleError = (error) => {
  console.error('API Error:', error);
  
  if (error.response && error.response.data && error.response.data.message) {
    toast.error(error.response.data.message);
    return error.response.data;
  }
  
  toast.error('An unexpected error occurred. Please try again.');
  return { success: false, message: 'An unexpected error occurred' };
};

/**
 * Makes a GET request to the API
 * @param {string} endpoint - The API endpoint
 * @param {Object} headers - Additional headers
 * @returns {Promise<Object>} - The response data
 */
export const get = async (endpoint, headers = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw { response: { data: errorData } };
    }

    return await response.json();
  } catch (error) {
    return handleError(error);
  }
};

/**
 * Makes a POST request to the API
 * @param {string} endpoint - The API endpoint
 * @param {Object} data - The request body
 * @param {Object} headers - Additional headers
 * @returns {Promise<Object>} - The response data
 */
export const post = async (endpoint, data, headers = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw { response: { data: errorData } };
    }

    return await response.json();
  } catch (error) {
    return handleError(error);
  }
};

/**
 * Makes a PUT request to the API
 * @param {string} endpoint - The API endpoint
 * @param {Object} data - The request body
 * @param {Object} headers - Additional headers
 * @returns {Promise<Object>} - The response data
 */
export const put = async (endpoint, data, headers = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw { response: { data: errorData } };
    }

    return await response.json();
  } catch (error) {
    return handleError(error);
  }
};

/**
 * Makes a DELETE request to the API
 * @param {string} endpoint - The API endpoint
 * @param {Object} headers - Additional headers
 * @returns {Promise<Object>} - The response data
 */
export const del = async (endpoint, headers = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw { response: { data: errorData } };
    }

    return await response.json();
  } catch (error) {
    return handleError(error);
  }
};

/**
 * Makes a multipart POST request to the API (for file uploads)
 * @param {string} endpoint - The API endpoint
 * @param {FormData} formData - The form data
 * @param {Object} headers - Additional headers
 * @returns {Promise<Object>} - The response data
 */
export const postFormData = async (endpoint, formData, headers = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        ...headers, // Don't set Content-Type, it will be set automatically with boundary
      },
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw { response: { data: errorData } };
    }

    return await response.json();
  } catch (error) {
    return handleError(error);
  }
};

/**
 * Makes a multipart PUT request to the API (for file updates)
 * @param {string} endpoint - The API endpoint
 * @param {FormData} formData - The form data
 * @param {Object} headers - Additional headers
 * @returns {Promise<Object>} - The response data
 */
export const putFormData = async (endpoint, formData, headers = {}) => {
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'PUT',
      headers: {
        ...headers, // Don't set Content-Type, it will be set automatically with boundary
      },
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw { response: { data: errorData } };
    }

    return await response.json();
  } catch (error) {
    return handleError(error);
  }
};

const api = {
  get,
  post,
  put,
  delete: del,
  postFormData,
  putFormData,
};

export default api;