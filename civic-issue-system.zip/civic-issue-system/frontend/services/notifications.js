/**
 * Notifications service for handling notification-related API calls
 */

import api from './api';

/**
 * Get all notifications for the current user
 * @returns {Promise<Object>} - Notifications response
 */
export const getNotifications = async () => {
  try {
    const response = await api.get('/notifications');
    return response;
  } catch (error) {
    console.error('Get notifications error:', error);
    throw error;
  }
};

/**
 * Mark a notification as read
 * @param {string} id - Notification ID
 * @returns {Promise<Object>} - Mark as read response
 */
export const markAsRead = async (id) => {
  try {
    const response = await api.put(`/notifications/${id}/read`);
    return response;
  } catch (error) {
    console.error(`Mark notification #${id} as read error:`, error);
    throw error;
  }
};

/**
 * Mark all notifications as read
 * @returns {Promise<Object>} - Mark all as read response
 */
export const markAllAsRead = async () => {
  try {
    const response = await api.put('/notifications/read-all');
    return response;
  } catch (error) {
    console.error('Mark all notifications as read error:', error);
    throw error;
  }
};

/**
 * Delete a notification
 * @param {string} id - Notification ID
 * @returns {Promise<Object>} - Delete notification response
 */
export const deleteNotification = async (id) => {
  try {
    const response = await api.delete(`/notifications/${id}`);
    return response;
  } catch (error) {
    console.error(`Delete notification #${id} error:`, error);
    throw error;
  }
};

/**
 * Delete all notifications
 * @returns {Promise<Object>} - Delete all notifications response
 */
export const deleteAllNotifications = async () => {
  try {
    const response = await api.delete('/notifications');
    return response;
  } catch (error) {
    console.error('Delete all notifications error:', error);
    throw error;
  }
};

/**
 * Get notification preferences
 * @returns {Promise<Object>} - Notification preferences response
 */
export const getNotificationPreferences = async () => {
  try {
    const response = await api.get('/notifications/preferences');
    return response;
  } catch (error) {
    console.error('Get notification preferences error:', error);
    throw error;
  }
};

/**
 * Update notification preferences
 * @param {Object} preferences - Notification preferences
 * @returns {Promise<Object>} - Update preferences response
 */
export const updateNotificationPreferences = async (preferences) => {
  try {
    const response = await api.put('/notifications/preferences', preferences);
    return response;
  } catch (error) {
    console.error('Update notification preferences error:', error);
    throw error;
  }
};

/**
 * Subscribe to push notifications
 * @param {Object} subscription - Push subscription object
 * @returns {Promise<Object>} - Subscribe response
 */
export const subscribeToPushNotifications = async (subscription) => {
  try {
    const response = await api.post('/notifications/push/subscribe', subscription);
    return response;
  } catch (error) {
    console.error('Subscribe to push notifications error:', error);
    throw error;
  }
};

/**
 * Unsubscribe from push notifications
 * @returns {Promise<Object>} - Unsubscribe response
 */
export const unsubscribeFromPushNotifications = async () => {
  try {
    const response = await api.post('/notifications/push/unsubscribe');
    return response;
  } catch (error) {
    console.error('Unsubscribe from push notifications error:', error);
    throw error;
  }
};

// Export all notification-related functions
const notificationService = {
  getNotifications,
  markAsRead,
  markAllAsRead,
  deleteNotification,
  deleteAllNotifications,
  getNotificationPreferences,
  updateNotificationPreferences,
  subscribeToPushNotifications,
  unsubscribeFromPushNotifications,
};

export default notificationService;