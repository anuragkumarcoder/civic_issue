/**
 * Analytics service for tracking user interactions and application usage
 */

// Configuration for analytics
let config = {
  enabled: process.env.NEXT_PUBLIC_ANALYTICS_ENABLED === 'true',
  anonymizeIp: true,
  trackingId: process.env.NEXT_PUBLIC_ANALYTICS_TRACKING_ID,
  debug: process.env.NODE_ENV === 'development',
};

/**
 * Initialize the analytics service
 * @param {Object} options - Configuration options
 */
export const initAnalytics = (options = {}) => {
  config = { ...config, ...options };
  
  if (!config.enabled || !config.trackingId) {
    console.log('Analytics disabled or tracking ID not provided');
    return;
  }
  
  // Load analytics script dynamically
  try {
    if (typeof window !== 'undefined') {
      // Example using Google Analytics
      const script = document.createElement('script');
      script.async = true;
      script.src = `https://www.googletagmanager.com/gtag/js?id=${config.trackingId}`;
      document.head.appendChild(script);
      
      window.dataLayer = window.dataLayer || [];
      window.gtag = function() {
        window.dataLayer.push(arguments);
      };
      
      window.gtag('js', new Date());
      window.gtag('config', config.trackingId, {
        anonymize_ip: config.anonymizeIp,
        debug_mode: config.debug,
      });
      
      console.log('Analytics initialized successfully');
    }
  } catch (error) {
    console.error('Failed to initialize analytics:', error);
  }
};

/**
 * Track a page view
 * @param {string} path - Page path
 * @param {string} title - Page title
 */
export const trackPageView = (path, title) => {
  if (!isAnalyticsEnabled()) return;
  
  try {
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', 'page_view', {
        page_path: path,
        page_title: title,
        page_location: window.location.href,
      });
      
      if (config.debug) {
        console.log(`Analytics: Tracked page view - ${path}`);
      }
    }
  } catch (error) {
    console.error('Failed to track page view:', error);
  }
};

/**
 * Track a custom event
 * @param {string} eventName - Name of the event
 * @param {Object} eventParams - Event parameters
 */
export const trackEvent = (eventName, eventParams = {}) => {
  if (!isAnalyticsEnabled()) return;
  
  try {
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('event', eventName, eventParams);
      
      if (config.debug) {
        console.log(`Analytics: Tracked event - ${eventName}`, eventParams);
      }
    }
  } catch (error) {
    console.error(`Failed to track event ${eventName}:`, error);
  }
};

/**
 * Track user authentication events
 * @param {string} method - Authentication method (e.g., 'email', 'google')
 * @param {string} action - Authentication action (e.g., 'login', 'register', 'logout')
 */
export const trackAuth = (method, action) => {
  trackEvent('authentication', {
    method,
    action,
  });
};

/**
 * Track issue-related events
 * @param {string} action - Issue action (e.g., 'create', 'update', 'delete', 'view', 'upvote')
 * @param {string} issueId - Issue ID (optional)
 * @param {string} category - Issue category (optional)
 */
export const trackIssueAction = (action, issueId = null, category = null) => {
  const params = { action };
  
  if (issueId) params.issue_id = issueId;
  if (category) params.category = category;
  
  trackEvent('issue_action', params);
};

/**
 * Track search events
 * @param {string} query - Search query
 * @param {number} resultCount - Number of results
 * @param {string} category - Search category (optional)
 */
export const trackSearch = (query, resultCount, category = null) => {
  const params = {
    search_term: query,
    result_count: resultCount,
  };
  
  if (category) params.category = category;
  
  trackEvent('search', params);
};

/**
 * Track feature usage
 * @param {string} featureName - Name of the feature
 * @param {Object} additionalParams - Additional parameters
 */
export const trackFeatureUsage = (featureName, additionalParams = {}) => {
  trackEvent('feature_usage', {
    feature_name: featureName,
    ...additionalParams,
  });
};

/**
 * Track errors
 * @param {string} errorType - Type of error
 * @param {string} errorMessage - Error message
 * @param {string} errorSource - Source of the error
 */
export const trackError = (errorType, errorMessage, errorSource) => {
  trackEvent('error', {
    error_type: errorType,
    error_message: errorMessage,
    error_source: errorSource,
  });
};

/**
 * Set user properties for analytics
 * @param {Object} properties - User properties
 */
export const setUserProperties = (properties) => {
  if (!isAnalyticsEnabled()) return;
  
  try {
    if (typeof window !== 'undefined' && window.gtag) {
      window.gtag('set', 'user_properties', properties);
      
      if (config.debug) {
        console.log('Analytics: Set user properties', properties);
      }
    }
  } catch (error) {
    console.error('Failed to set user properties:', error);
  }
};

/**
 * Check if analytics is enabled
 * @returns {boolean} - Whether analytics is enabled
 */
export const isAnalyticsEnabled = () => {
  return config.enabled && config.trackingId && typeof window !== 'undefined';
};

/**
 * Enable or disable analytics
 * @param {boolean} enabled - Whether to enable analytics
 */
export const setAnalyticsEnabled = (enabled) => {
  config.enabled = enabled;
  
  // Store user preference in localStorage
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem('analytics_enabled', enabled ? 'true' : 'false');
      
      if (config.debug) {
        console.log(`Analytics: ${enabled ? 'Enabled' : 'Disabled'}`);
      }
    } catch (error) {
      console.error('Failed to save analytics preference:', error);
    }
  }
};

// Export all analytics functions
const analyticsService = {
  initAnalytics,
  trackPageView,
  trackEvent,
  trackAuth,
  trackIssueAction,
  trackSearch,
  trackFeatureUsage,
  trackError,
  setUserProperties,
  isAnalyticsEnabled,
  setAnalyticsEnabled,
};

export default analyticsService;