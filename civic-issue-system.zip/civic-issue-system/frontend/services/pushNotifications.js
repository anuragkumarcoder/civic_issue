/**
 * Push Notifications service for handling browser push notifications
 */

import api from './api';

// Check if browser supports push notifications
const isPushSupported = () => {
  return 'serviceWorker' in navigator && 'PushManager' in window;
};

// Store the service worker registration
let swRegistration = null;

/**
 * Initialize push notifications
 * @returns {Promise<ServiceWorkerRegistration|null>} - Service worker registration
 */
export const initializePushNotifications = async () => {
  if (!isPushSupported()) {
    console.warn('Push notifications are not supported in this browser');
    return null;
  }
  
  try {
    // Register service worker
    swRegistration = await navigator.serviceWorker.register('/service-worker.js');
    console.log('Service Worker registered successfully', swRegistration);
    return swRegistration;
  } catch (error) {
    console.error('Service Worker registration failed:', error);
    return null;
  }
};

/**
 * Request permission for push notifications
 * @returns {Promise<string>} - Permission status ('granted', 'denied', or 'default')
 */
export const requestNotificationPermission = async () => {
  if (!isPushSupported()) {
    console.warn('Push notifications are not supported in this browser');
    return 'denied';
  }
  
  try {
    const permission = await Notification.requestPermission();
    console.log('Notification permission status:', permission);
    return permission;
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    return 'denied';
  }
};

/**
 * Get current notification permission status
 * @returns {string} - Permission status ('granted', 'denied', or 'default')
 */
export const getNotificationPermission = () => {
  if (!isPushSupported()) {
    return 'denied';
  }
  
  return Notification.permission;
};

/**
 * Subscribe to push notifications
 * @returns {Promise<Object|null>} - Push subscription
 */
export const subscribeToPushNotifications = async () => {
  if (!isPushSupported() || !swRegistration) {
    console.warn('Push notifications are not supported or service worker not registered');
    return null;
  }
  
  try {
    // Get the server's public key
    const response = await api.get('/notifications/vapid-public-key');
    const vapidPublicKey = response.vapidPublicKey;
    
    // Convert the public key to Uint8Array
    const applicationServerKey = urlBase64ToUint8Array(vapidPublicKey);
    
    // Subscribe to push notifications
    const subscription = await swRegistration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey,
    });
    
    console.log('User is subscribed to push notifications');
    
    // Send the subscription to the server
    await saveSubscription(subscription);
    
    return subscription;
  } catch (error) {
    console.error('Failed to subscribe to push notifications:', error);
    return null;
  }
};

/**
 * Unsubscribe from push notifications
 * @returns {Promise<boolean>} - Whether unsubscription was successful
 */
export const unsubscribeFromPushNotifications = async () => {
  if (!isPushSupported() || !swRegistration) {
    console.warn('Push notifications are not supported or service worker not registered');
    return false;
  }
  
  try {
    const subscription = await swRegistration.pushManager.getSubscription();
    
    if (!subscription) {
      console.log('No push subscription found');
      return true;
    }
    
    // Unsubscribe from push notifications
    const success = await subscription.unsubscribe();
    
    if (success) {
      console.log('User is unsubscribed from push notifications');
      
      // Notify the server about unsubscription
      await deleteSubscription(subscription);
    }
    
    return success;
  } catch (error) {
    console.error('Error unsubscribing from push notifications:', error);
    return false;
  }
};

/**
 * Check if user is subscribed to push notifications
 * @returns {Promise<boolean>} - Whether user is subscribed
 */
export const isPushNotificationsSubscribed = async () => {
  if (!isPushSupported() || !swRegistration) {
    return false;
  }
  
  try {
    const subscription = await swRegistration.pushManager.getSubscription();
    return !!subscription;
  } catch (error) {
    console.error('Error checking push subscription:', error);
    return false;
  }
};

/**
 * Save push subscription to server
 * @param {PushSubscription} subscription - Push subscription
 * @returns {Promise<Object>} - Save subscription response
 */
const saveSubscription = async (subscription) => {
  try {
    const response = await api.post('/notifications/subscriptions', {
      subscription: subscription.toJSON(),
    });
    return response;
  } catch (error) {
    console.error('Error saving push subscription:', error);
    throw error;
  }
};

/**
 * Delete push subscription from server
 * @param {PushSubscription} subscription - Push subscription
 * @returns {Promise<Object>} - Delete subscription response
 */
const deleteSubscription = async (subscription) => {
  try {
    const response = await api.delete('/notifications/subscriptions', {
      data: { subscription: subscription.toJSON() },
    });
    return response;
  } catch (error) {
    console.error('Error deleting push subscription:', error);
    throw error;
  }
};

/**
 * Update notification preferences
 * @param {Object} preferences - Notification preferences
 * @returns {Promise<Object>} - Update preferences response
 */
export const updateNotificationPreferences = async (preferences) => {
  try {
    const response = await api.put('/notifications/preferences', preferences);
    return response;
  } catch (error) {
    console.error('Error updating notification preferences:', error);
    throw error;
  }
};

/**
 * Get notification preferences
 * @returns {Promise<Object>} - Notification preferences response
 */
export const getNotificationPreferences = async () => {
  try {
    const response = await api.get('/notifications/preferences');
    return response;
  } catch (error) {
    console.error('Error getting notification preferences:', error);
    throw error;
  }
};

/**
 * Display a notification
 * @param {Object} notification - Notification data
 * @returns {Promise<Notification|null>} - Notification object
 */
export const displayNotification = async (notification) => {
  if (!isPushSupported() || Notification.permission !== 'granted') {
    console.warn('Push notifications are not supported or permission not granted');
    return null;
  }
  
  try {
    const {
      title,
      body,
      icon = '/icons/notification-icon.png',
      badge = '/icons/notification-badge.png',
      tag,
      data,
      actions = [],
    } = notification;
    
    const notificationOptions = {
      body,
      icon,
      badge,
      tag,
      data,
      actions,
      requireInteraction: true,
      renotify: true,
    };
    
    if (swRegistration) {
      // Use service worker to show notification
      await swRegistration.showNotification(title, notificationOptions);
      return null; // Service worker handles the notification
    } else {
      // Fallback to regular notification
      const notificationInstance = new Notification(title, notificationOptions);
      return notificationInstance;
    }
  } catch (error) {
    console.error('Error displaying notification:', error);
    return null;
  }
};

/**
 * Close a notification
 * @param {string} tag - Notification tag
 * @returns {Promise<boolean>} - Whether closing was successful
 */
export const closeNotification = async (tag) => {
  if (!isPushSupported() || !swRegistration) {
    return false;
  }
  
  try {
    const notifications = await swRegistration.getNotifications({ tag });
    
    notifications.forEach(notification => {
      notification.close();
    });
    
    return true;
  } catch (error) {
    console.error('Error closing notification:', error);
    return false;
  }
};

/**
 * Close all notifications
 * @returns {Promise<boolean>} - Whether closing was successful
 */
export const closeAllNotifications = async () => {
  if (!isPushSupported() || !swRegistration) {
    return false;
  }
  
  try {
    const notifications = await swRegistration.getNotifications();
    
    notifications.forEach(notification => {
      notification.close();
    });
    
    return true;
  } catch (error) {
    console.error('Error closing all notifications:', error);
    return false;
  }
};

/**
 * Convert base64 string to Uint8Array
 * @param {string} base64String - Base64 string
 * @returns {Uint8Array} - Uint8Array
 */
const urlBase64ToUint8Array = (base64String) => {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  
  return outputArray;
};

// Export all push notification-related functions
const pushNotificationsService = {
  isPushSupported,
  initializePushNotifications,
  requestNotificationPermission,
  getNotificationPermission,
  subscribeToPushNotifications,
  unsubscribeFromPushNotifications,
  isPushNotificationsSubscribed,
  updateNotificationPreferences,
  getNotificationPreferences,
  displayNotification,
  closeNotification,
  closeAllNotifications,
};

export default pushNotificationsService;