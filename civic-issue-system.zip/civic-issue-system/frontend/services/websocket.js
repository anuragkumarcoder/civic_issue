/**
 * WebSocket service for handling real-time updates
 */

// Store the WebSocket instance
let socket = null;

// Store event listeners
const listeners = {};

// Reconnection settings
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;
const reconnectDelay = 3000; // 3 seconds
let reconnectTimeout = null;

/**
 * Initialize WebSocket connection
 * @param {string} token - Authentication token
 * @returns {WebSocket} - WebSocket instance
 */
export const initializeWebSocket = (token) => {
  if (socket && socket.readyState === WebSocket.OPEN) {
    console.log('WebSocket connection already established');
    return socket;
  }
  
  try {
    const wsUrl = process.env.NEXT_PUBLIC_WS_URL || 
      process.env.NEXT_PUBLIC_API_URL.replace('http', 'ws').replace('https', 'wss');
    
    socket = new WebSocket(`${wsUrl}/ws?token=${token}`);
    
    socket.onopen = () => {
      console.log('WebSocket connection established');
      reconnectAttempts = 0;
      
      // Notify connection listeners
      triggerEvent('connection', { status: 'connected' });
    };
    
    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Trigger event based on message type
        if (data.type) {
          triggerEvent(data.type, data.payload);
        }
        
        // Also trigger a general message event
        triggerEvent('message', data);
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      triggerEvent('error', { error });
    };
    
    socket.onclose = (event) => {
      console.log('WebSocket connection closed:', event.code, event.reason);
      triggerEvent('connection', { status: 'disconnected', code: event.code, reason: event.reason });
      
      // Attempt to reconnect if not a normal closure
      if (event.code !== 1000 && event.code !== 1001) {
        attemptReconnect(token);
      }
    };
    
    return socket;
  } catch (error) {
    console.error('Failed to initialize WebSocket:', error);
    return null;
  }
};

/**
 * Attempt to reconnect to WebSocket
 * @param {string} token - Authentication token
 */
const attemptReconnect = (token) => {
  if (reconnectAttempts >= maxReconnectAttempts) {
    console.log('Maximum reconnection attempts reached');
    triggerEvent('connection', { status: 'failed', reason: 'Maximum reconnection attempts reached' });
    return;
  }
  
  reconnectAttempts++;
  
  console.log(`Attempting to reconnect (${reconnectAttempts}/${maxReconnectAttempts}) in ${reconnectDelay}ms...`);
  triggerEvent('connection', { status: 'reconnecting', attempt: reconnectAttempts, maxAttempts: maxReconnectAttempts });
  
  clearTimeout(reconnectTimeout);
  reconnectTimeout = setTimeout(() => {
    initializeWebSocket(token);
  }, reconnectDelay);
};

/**
 * Close WebSocket connection
 */
export const closeWebSocket = () => {
  if (socket) {
    socket.close(1000, 'User initiated disconnect');
    socket = null;
    clearTimeout(reconnectTimeout);
  }
};

/**
 * Send message through WebSocket
 * @param {string} type - Message type
 * @param {Object} payload - Message payload
 * @returns {boolean} - Whether message was sent
 */
export const sendMessage = (type, payload) => {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    console.error('WebSocket not connected');
    return false;
  }
  
  try {
    const message = JSON.stringify({
      type,
      payload,
    });
    
    socket.send(message);
    return true;
  } catch (error) {
    console.error('Error sending WebSocket message:', error);
    return false;
  }
};

/**
 * Add event listener
 * @param {string} event - Event name
 * @param {Function} callback - Event callback
 */
export const addEventListener = (event, callback) => {
  if (!listeners[event]) {
    listeners[event] = [];
  }
  
  listeners[event].push(callback);
};

/**
 * Remove event listener
 * @param {string} event - Event name
 * @param {Function} callback - Event callback
 */
export const removeEventListener = (event, callback) => {
  if (!listeners[event]) return;
  
  listeners[event] = listeners[event].filter(cb => cb !== callback);
};

/**
 * Trigger event
 * @param {string} event - Event name
 * @param {Object} data - Event data
 */
const triggerEvent = (event, data) => {
  if (!listeners[event]) return;
  
  listeners[event].forEach(callback => {
    try {
      callback(data);
    } catch (error) {
      console.error(`Error in ${event} event listener:`, error);
    }
  });
};

/**
 * Check if WebSocket is connected
 * @returns {boolean} - Whether WebSocket is connected
 */
export const isConnected = () => {
  return socket && socket.readyState === WebSocket.OPEN;
};

/**
 * Get WebSocket connection state
 * @returns {number} - WebSocket readyState
 */
export const getConnectionState = () => {
  if (!socket) return -1;
  return socket.readyState;
};

/**
 * Subscribe to issue updates
 * @param {string} issueId - Issue ID
 * @returns {boolean} - Whether subscription was successful
 */
export const subscribeToIssue = (issueId) => {
  return sendMessage('subscribe', { type: 'issue', id: issueId });
};

/**
 * Unsubscribe from issue updates
 * @param {string} issueId - Issue ID
 * @returns {boolean} - Whether unsubscription was successful
 */
export const unsubscribeFromIssue = (issueId) => {
  return sendMessage('unsubscribe', { type: 'issue', id: issueId });
};

/**
 * Subscribe to user notifications
 * @returns {boolean} - Whether subscription was successful
 */
export const subscribeToNotifications = () => {
  return sendMessage('subscribe', { type: 'notifications' });
};

/**
 * Unsubscribe from user notifications
 * @returns {boolean} - Whether unsubscription was successful
 */
export const unsubscribeFromNotifications = () => {
  return sendMessage('unsubscribe', { type: 'notifications' });
};

/**
 * Subscribe to category updates
 * @param {string} categoryId - Category ID
 * @returns {boolean} - Whether subscription was successful
 */
export const subscribeToCategory = (categoryId) => {
  return sendMessage('subscribe', { type: 'category', id: categoryId });
};

/**
 * Unsubscribe from category updates
 * @param {string} categoryId - Category ID
 * @returns {boolean} - Whether unsubscription was successful
 */
export const unsubscribeFromCategory = (categoryId) => {
  return sendMessage('unsubscribe', { type: 'category', id: categoryId });
};

/**
 * Subscribe to area updates
 * @param {Object} coordinates - Area coordinates
 * @param {number} radius - Area radius in meters
 * @returns {boolean} - Whether subscription was successful
 */
export const subscribeToArea = (coordinates, radius) => {
  return sendMessage('subscribe', {
    type: 'area',
    coordinates,
    radius,
  });
};

/**
 * Unsubscribe from area updates
 * @returns {boolean} - Whether unsubscription was successful
 */
export const unsubscribeFromArea = () => {
  return sendMessage('unsubscribe', { type: 'area' });
};

// Export all WebSocket-related functions
const websocketService = {
  initializeWebSocket,
  closeWebSocket,
  sendMessage,
  addEventListener,
  removeEventListener,
  isConnected,
  getConnectionState,
  subscribeToIssue,
  unsubscribeFromIssue,
  subscribeToNotifications,
  unsubscribeFromNotifications,
  subscribeToCategory,
  unsubscribeFromCategory,
  subscribeToArea,
  unsubscribeFromArea,
};

export default websocketService;