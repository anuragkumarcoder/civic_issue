/**
 * Export/Import service for handling data export and import
 */

import api from './api';

/**
 * Export user data
 * @param {Object} options - Export options
 * @returns {Promise<Blob>} - Exported data as blob
 */
export const exportUserData = async (options = {}) => {
  try {
    const {
      format = 'json', // json, csv, pdf
      dataTypes = ['issues', 'comments', 'profile'], // What data to include
    } = options;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('format', format);
    dataTypes.forEach(type => queryParams.append('dataTypes', type));
    
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/export/user?${queryParams.toString()}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
      },
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const blob = await response.blob();
    return blob;
  } catch (error) {
    console.error('Export user data error:', error);
    throw error;
  }
};

/**
 * Export issue data
 * @param {string} issueId - Issue ID
 * @param {Object} options - Export options
 * @returns {Promise<Blob>} - Exported data as blob
 */
export const exportIssue = async (issueId, options = {}) => {
  try {
    const {
      format = 'json', // json, csv, pdf
      includeComments = true,
      includeAttachments = false,
    } = options;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('format', format);
    queryParams.append('includeComments', includeComments.toString());
    queryParams.append('includeAttachments', includeAttachments.toString());
    
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/export/issues/${issueId}?${queryParams.toString()}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
      },
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const blob = await response.blob();
    return blob;
  } catch (error) {
    console.error(`Export issue #${issueId} error:`, error);
    throw error;
  }
};

/**
 * Export multiple issues
 * @param {Array<string>} issueIds - Issue IDs
 * @param {Object} options - Export options
 * @returns {Promise<Blob>} - Exported data as blob
 */
export const exportMultipleIssues = async (issueIds, options = {}) => {
  try {
    const {
      format = 'json', // json, csv, pdf
      includeComments = true,
      includeAttachments = false,
    } = options;
    
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/export/issues`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
      },
      body: JSON.stringify({
        issueIds,
        format,
        includeComments,
        includeAttachments,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const blob = await response.blob();
    return blob;
  } catch (error) {
    console.error('Export multiple issues error:', error);
    throw error;
  }
};

/**
 * Export issues by filter
 * @param {Object} filters - Filter criteria
 * @param {Object} options - Export options
 * @returns {Promise<Blob>} - Exported data as blob
 */
export const exportIssuesByFilter = async (filters = {}, options = {}) => {
  try {
    const {
      format = 'json', // json, csv, pdf
      includeComments = true,
      includeAttachments = false,
    } = options;
    
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/export/issues/filter`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
      },
      body: JSON.stringify({
        filters,
        format,
        includeComments,
        includeAttachments,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const blob = await response.blob();
    return blob;
  } catch (error) {
    console.error('Export issues by filter error:', error);
    throw error;
  }
};

/**
 * Export statistics data
 * @param {Object} options - Export options
 * @returns {Promise<Blob>} - Exported data as blob
 */
export const exportStatistics = async (options = {}) => {
  try {
    const {
      format = 'json', // json, csv, pdf
      timeframe = 'month', // day, week, month, year, all
      metrics = ['issues', 'users', 'categories', 'statuses'],
    } = options;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('format', format);
    queryParams.append('timeframe', timeframe);
    metrics.forEach(metric => queryParams.append('metrics', metric));
    
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/export/statistics?${queryParams.toString()}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
      },
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const blob = await response.blob();
    return blob;
  } catch (error) {
    console.error('Export statistics error:', error);
    throw error;
  }
};

/**
 * Import user data
 * @param {File} file - File containing user data
 * @param {Object} options - Import options
 * @returns {Promise<Object>} - Import response
 */
export const importUserData = async (file, options = {}) => {
  try {
    const {
      overwrite = false,
      dataTypes = ['issues', 'comments', 'profile'],
    } = options;
    
    const formData = new FormData();
    formData.append('file', file);
    formData.append('overwrite', overwrite.toString());
    dataTypes.forEach(type => formData.append('dataTypes', type));
    
    const response = await api.postFormData('/import/user', formData);
    return response;
  } catch (error) {
    console.error('Import user data error:', error);
    throw error;
  }
};

/**
 * Import issues
 * @param {File} file - File containing issue data
 * @param {Object} options - Import options
 * @returns {Promise<Object>} - Import response
 */
export const importIssues = async (file, options = {}) => {
  try {
    const {
      overwrite = false,
      updateExisting = true,
    } = options;
    
    const formData = new FormData();
    formData.append('file', file);
    formData.append('overwrite', overwrite.toString());
    formData.append('updateExisting', updateExisting.toString());
    
    const response = await api.postFormData('/import/issues', formData);
    return response;
  } catch (error) {
    console.error('Import issues error:', error);
    throw error;
  }
};

/**
 * Generate a report
 * @param {Object} options - Report options
 * @returns {Promise<Blob>} - Generated report as blob
 */
export const generateReport = async (options = {}) => {
  try {
    const {
      type = 'issues', // issues, users, activity
      format = 'pdf', // pdf, excel, csv
      timeframe = 'month', // day, week, month, year, all
      filters = {},
    } = options;
    
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/reports/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
      },
      body: JSON.stringify({
        type,
        format,
        timeframe,
        filters,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const blob = await response.blob();
    return blob;
  } catch (error) {
    console.error('Generate report error:', error);
    throw error;
  }
};

/**
 * Download exported data as file
 * @param {Blob} blob - Data blob
 * @param {string} filename - File name
 */
export const downloadExportedData = (blob, filename) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// Export all export/import-related functions
const exportImportService = {
  exportUserData,
  exportIssue,
  exportMultipleIssues,
  exportIssuesByFilter,
  exportStatistics,
  importUserData,
  importIssues,
  generateReport,
  downloadExportedData,
};

export default exportImportService;