/**
 * Utility service for common application functions
 */

/**
 * Format a date string to a readable format
 * @param {string} dateString - ISO date string
 * @param {Object} options - Intl.DateTimeFormat options
 * @returns {string} - Formatted date string
 */
export const formatDate = (dateString, options = {}) => {
  if (!dateString) return '';
  
  const date = new Date(dateString);
  
  // Default options
  const defaultOptions = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    ...options
  };
  
  // If date is invalid, return empty string
  if (isNaN(date.getTime())) return '';
  
  return new Intl.DateTimeFormat('en-US', defaultOptions).format(date);
};

/**
 * Format a date relative to now (e.g., "2 hours ago")
 * @param {string} dateString - ISO date string
 * @returns {string} - Relative time string
 */
export const formatRelativeTime = (dateString) => {
  if (!dateString) return '';
  
  const date = new Date(dateString);
  const now = new Date();
  
  // If date is invalid, return empty string
  if (isNaN(date.getTime())) return '';
  
  const diffInSeconds = Math.floor((now - date) / 1000);
  
  // Less than a minute
  if (diffInSeconds < 60) {
    return 'just now';
  }
  
  // Less than an hour
  if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60);
    return `${minutes} ${minutes === 1 ? 'minute' : 'minutes'} ago`;
  }
  
  // Less than a day
  if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600);
    return `${hours} ${hours === 1 ? 'hour' : 'hours'} ago`;
  }
  
  // Less than a week
  if (diffInSeconds < 604800) {
    const days = Math.floor(diffInSeconds / 86400);
    return `${days} ${days === 1 ? 'day' : 'days'} ago`;
  }
  
  // Less than a month
  if (diffInSeconds < 2592000) {
    const weeks = Math.floor(diffInSeconds / 604800);
    return `${weeks} ${weeks === 1 ? 'week' : 'weeks'} ago`;
  }
  
  // Less than a year
  if (diffInSeconds < 31536000) {
    const months = Math.floor(diffInSeconds / 2592000);
    return `${months} ${months === 1 ? 'month' : 'months'} ago`;
  }
  
  // More than a year
  const years = Math.floor(diffInSeconds / 31536000);
  return `${years} ${years === 1 ? 'year' : 'years'} ago`;
};

/**
 * Truncate text to a specified length
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length
 * @returns {string} - Truncated text
 */
export const truncateText = (text, maxLength = 100) => {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  
  return `${text.substring(0, maxLength)}...`;
};

/**
 * Generate a random ID
 * @param {number} length - Length of the ID
 * @returns {string} - Random ID
 */
export const generateId = (length = 10) => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  
  return result;
};

/**
 * Debounce a function call
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @returns {Function} - Debounced function
 */
export const debounce = (func, wait = 300) => {
  let timeout;
  
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

/**
 * Throttle a function call
 * @param {Function} func - Function to throttle
 * @param {number} limit - Limit in milliseconds
 * @returns {Function} - Throttled function
 */
export const throttle = (func, limit = 300) => {
  let inThrottle;
  
  return function executedFunction(...args) {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => {
        inThrottle = false;
      }, limit);
    }
  };
};

/**
 * Deep clone an object
 * @param {Object} obj - Object to clone
 * @returns {Object} - Cloned object
 */
export const deepClone = (obj) => {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  
  if (obj instanceof Date) {
    return new Date(obj.getTime());
  }
  
  if (obj instanceof Array) {
    return obj.map(item => deepClone(item));
  }
  
  if (obj instanceof Object) {
    const copy = {};
    Object.keys(obj).forEach(key => {
      copy[key] = deepClone(obj[key]);
    });
    return copy;
  }
  
  return obj;
};

/**
 * Check if an object is empty
 * @param {Object} obj - Object to check
 * @returns {boolean} - True if empty
 */
export const isEmptyObject = (obj) => {
  return obj && Object.keys(obj).length === 0 && obj.constructor === Object;
};

/**
 * Format a number with commas
 * @param {number} number - Number to format
 * @returns {string} - Formatted number
 */
export const formatNumber = (number) => {
  if (number === null || number === undefined) return '';
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

/**
 * Get query parameters from URL
 * @returns {Object} - Query parameters
 */
export const getQueryParams = () => {
  if (typeof window === 'undefined') return {};
  
  const params = {};
  const queryString = window.location.search.substring(1);
  const pairs = queryString.split('&');
  
  for (let i = 0; i < pairs.length; i++) {
    if (!pairs[i]) continue;
    
    const pair = pairs[i].split('=');
    params[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1] || '');
  }
  
  return params;
};

/**
 * Create a URL with query parameters
 * @param {string} baseUrl - Base URL
 * @param {Object} params - Query parameters
 * @returns {string} - URL with query parameters
 */
export const createUrlWithParams = (baseUrl, params = {}) => {
  const url = new URL(baseUrl, window.location.origin);
  
  Object.keys(params).forEach(key => {
    if (params[key] !== undefined && params[key] !== null && params[key] !== '') {
      url.searchParams.append(key, params[key]);
    }
  });
  
  return url.toString();
};

/**
 * Utility functions for working with local storage
 */
export const storage = {
  /**
   * Get an item from local storage
   * @param {string} key - Storage key
   * @param {boolean} parse - Whether to parse the value as JSON
   * @returns {any} - Stored value
   */
  get: (key, parse = true) => {
    if (typeof window === 'undefined') return null;
    
    try {
      const value = localStorage.getItem(key);
      return parse && value ? JSON.parse(value) : value;
    } catch (error) {
      console.error(`Error getting item from localStorage: ${error}`);
      return null;
    }
  },
  
  /**
   * Set an item in local storage
   * @param {string} key - Storage key
   * @param {any} value - Value to store
   * @param {boolean} stringify - Whether to stringify the value
   * @returns {boolean} - Success status
   */
  set: (key, value, stringify = true) => {
    if (typeof window === 'undefined') return false;
    
    try {
      const storageValue = stringify ? JSON.stringify(value) : value;
      localStorage.setItem(key, storageValue);
      return true;
    } catch (error) {
      console.error(`Error setting item in localStorage: ${error}`);
      return false;
    }
  },
  
  /**
   * Remove an item from local storage
   * @param {string} key - Storage key
   * @returns {boolean} - Success status
   */
  remove: (key) => {
    if (typeof window === 'undefined') return false;
    
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error(`Error removing item from localStorage: ${error}`);
      return false;
    }
  },
  
  /**
   * Clear all items from local storage
   * @returns {boolean} - Success status
   */
  clear: () => {
    if (typeof window === 'undefined') return false;
    
    try {
      localStorage.clear();
      return true;
    } catch (error) {
      console.error(`Error clearing localStorage: ${error}`);
      return false;
    }
  },
};

/**
 * Utility functions for working with cookies
 */
export const cookies = {
  /**
   * Get a cookie by name
   * @param {string} name - Cookie name
   * @returns {string} - Cookie value
   */
  get: (name) => {
    if (typeof document === 'undefined') return null;
    
    const nameEQ = `${name}=`;
    const ca = document.cookie.split(';');
    
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i];
      while (c.charAt(0) === ' ') c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    
    return null;
  },
  
  /**
   * Set a cookie
   * @param {string} name - Cookie name
   * @param {string} value - Cookie value
   * @param {number} days - Expiration in days
   */
  set: (name, value, days = 7) => {
    if (typeof document === 'undefined') return;
    
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    const expires = `; expires=${date.toUTCString()}`;
    document.cookie = `${name}=${value}${expires}; path=/`;
  },
  
  /**
   * Delete a cookie
   * @param {string} name - Cookie name
   */
  delete: (name) => {
    if (typeof document === 'undefined') return;
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
  },
};

/**
 * Validate an email address
 * @param {string} email - Email to validate
 * @returns {boolean} - Validation result
 */
export const validateEmail = (email) => {
  const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return re.test(String(email).toLowerCase());
};

/**
 * Validate a password strength
 * @param {string} password - Password to validate
 * @returns {Object} - Validation result and strength
 */
export const validatePassword = (password) => {
  if (!password) {
    return { valid: false, strength: 0, message: 'Password is required' };
  }
  
  let strength = 0;
  const messages = [];
  
  // Length check
  if (password.length < 8) {
    messages.push('Password should be at least 8 characters');
  } else {
    strength += 1;
  }
  
  // Contains uppercase
  if (!/[A-Z]/.test(password)) {
    messages.push('Password should contain at least one uppercase letter');
  } else {
    strength += 1;
  }
  
  // Contains lowercase
  if (!/[a-z]/.test(password)) {
    messages.push('Password should contain at least one lowercase letter');
  } else {
    strength += 1;
  }
  
  // Contains number
  if (!/[0-9]/.test(password)) {
    messages.push('Password should contain at least one number');
  } else {
    strength += 1;
  }
  
  // Contains special character
  if (!/[^A-Za-z0-9]/.test(password)) {
    messages.push('Password should contain at least one special character');
  } else {
    strength += 1;
  }
  
  return {
    valid: strength >= 3,
    strength: strength,
    message: messages.join('. '),
  };
};

/**
 * Get a user's initials from their name
 * @param {string} name - User's name
 * @returns {string} - Initials
 */
export const getInitials = (name) => {
  if (!name) return '';
  
  const names = name.split(' ').filter(n => n.length > 0);
  
  if (names.length === 0) return '';
  if (names.length === 1) return names[0].charAt(0).toUpperCase();
  
  return (names[0].charAt(0) + names[names.length - 1].charAt(0)).toUpperCase();
};

/**
 * Generate a random color based on a string
 * @param {string} str - Input string
 * @returns {string} - Hex color code
 */
export const stringToColor = (str) => {
  if (!str) return '#000000';
  
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  let color = '#';
  for (let i = 0; i < 3; i++) {
    const value = (hash >> (i * 8)) & 0xFF;
    color += ('00' + value.toString(16)).substr(-2);
  }
  
  return color;
};

/**
 * Utility functions for working with arrays
 */
export const arrayUtils = {
  /**
   * Group array items by a key
   * @param {Array} array - Array to group
   * @param {string|Function} key - Grouping key or function
   * @returns {Object} - Grouped object
   */
  groupBy: (array, key) => {
    return array.reduce((result, item) => {
      const groupKey = typeof key === 'function' ? key(item) : item[key];
      if (!result[groupKey]) {
        result[groupKey] = [];
      }
      result[groupKey].push(item);
      return result;
    }, {});
  },
  
  /**
   * Sort array by a key
   * @param {Array} array - Array to sort
   * @param {string} key - Sort key
   * @param {string} direction - Sort direction ('asc' or 'desc')
   * @returns {Array} - Sorted array
   */
  sortBy: (array, key, direction = 'asc') => {
    const sortedArray = [...array];
    
    return sortedArray.sort((a, b) => {
      if (a[key] < b[key]) return direction === 'asc' ? -1 : 1;
      if (a[key] > b[key]) return direction === 'asc' ? 1 : -1;
      return 0;
    });
  },
  
  /**
   * Remove duplicates from array
   * @param {Array} array - Array with duplicates
   * @param {string} key - Key to check for duplicates
   * @returns {Array} - Array without duplicates
   */
  unique: (array, key) => {
    if (key) {
      const seen = new Set();
      return array.filter(item => {
        const value = item[key];
        if (seen.has(value)) return false;
        seen.add(value);
        return true;
      });
    }
    
    return [...new Set(array)];
  },
};

/**
 * Format a currency amount
 * @param {number} amount - Amount to format
 * @param {string} currency - Currency code
 * @param {string} locale - Locale code
 * @returns {string} - Formatted currency
 */
export const formatCurrency = (amount, currency = 'USD', locale = 'en-US') => {
  if (amount === null || amount === undefined) return '';
  
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};

/**
 * Get browser and device information
 * @returns {Object} - Browser and device info
 */
export const getBrowserInfo = () => {
  if (typeof window === 'undefined') {
    return {
      browser: 'unknown',
      version: 'unknown',
      os: 'unknown',
      mobile: false,
      userAgent: 'unknown',
    };
  }
  
  const userAgent = navigator.userAgent;
  let browser = 'unknown';
  let version = 'unknown';
  let os = 'unknown';
  let mobile = false;
  
  // Detect browser
  if (userAgent.indexOf('Firefox') > -1) {
    browser = 'Firefox';
    version = userAgent.match(/Firefox\/(\d+\.\d+)/)[1];
  } else if (userAgent.indexOf('Chrome') > -1 && userAgent.indexOf('Edge') === -1) {
    browser = 'Chrome';
    version = userAgent.match(/Chrome\/(\d+\.\d+)/)[1];
  } else if (userAgent.indexOf('Safari') > -1 && userAgent.indexOf('Chrome') === -1) {
    browser = 'Safari';
    version = userAgent.match(/Version\/(\d+\.\d+)/)[1];
  } else if (userAgent.indexOf('Edge') > -1) {
    browser = 'Edge';
    version = userAgent.match(/Edge\/(\d+\.\d+)/)[1];
  } else if (userAgent.indexOf('MSIE') > -1 || userAgent.indexOf('Trident') > -1) {
    browser = 'Internet Explorer';
    version = userAgent.match(/(?:MSIE |rv:)(\d+\.\d+)/)[1];
  }
  
  // Detect OS
  if (userAgent.indexOf('Windows') > -1) {
    os = 'Windows';
  } else if (userAgent.indexOf('Mac') > -1) {
    os = 'MacOS';
  } else if (userAgent.indexOf('Linux') > -1) {
    os = 'Linux';
  } else if (userAgent.indexOf('Android') > -1) {
    os = 'Android';
    mobile = true;
  } else if (userAgent.indexOf('iPhone') > -1 || userAgent.indexOf('iPad') > -1) {
    os = 'iOS';
    mobile = true;
  }
  
  // Detect mobile
  if (!mobile) {
    mobile = /Mobi|Android/i.test(userAgent);
  }
  
  return {
    browser,
    version,
    os,
    mobile,
    userAgent,
  };
};

/**
 * Utility functions for working with objects
 */
export const objectUtils = {
  /**
   * Pick specific properties from an object
   * @param {Object} obj - Source object
   * @param {Array} keys - Keys to pick
   * @returns {Object} - New object with picked properties
   */
  pick: (obj, keys) => {
    return keys.reduce((result, key) => {
      if (obj.hasOwnProperty(key)) {
        result[key] = obj[key];
      }
      return result;
    }, {});
  },
  
  /**
   * Omit specific properties from an object
   * @param {Object} obj - Source object
   * @param {Array} keys - Keys to omit
   * @returns {Object} - New object without omitted properties
   */
  omit: (obj, keys) => {
    const result = { ...obj };
    keys.forEach(key => {
      delete result[key];
    });
    return result;
  },
  
  /**
   * Flatten a nested object
   * @param {Object} obj - Nested object
   * @param {string} prefix - Key prefix
   * @returns {Object} - Flattened object
   */
  flatten: (obj, prefix = '') => {
    return Object.keys(obj).reduce((acc, k) => {
      const pre = prefix.length ? `${prefix}.` : '';
      if (typeof obj[k] === 'object' && obj[k] !== null && !Array.isArray(obj[k])) {
        Object.assign(acc, objectUtils.flatten(obj[k], pre + k));
      } else {
        acc[pre + k] = obj[k];
      }
      return acc;
    }, {});
  },
};

/**
 * Utility functions for working with strings
 */
export const stringUtils = {
  /**
   * Capitalize the first letter of a string
   * @param {string} str - Input string
   * @returns {string} - Capitalized string
   */
  capitalize: (str) => {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  },
  
  /**
   * Convert a string to camelCase
   * @param {string} str - Input string
   * @returns {string} - camelCase string
   */
  camelCase: (str) => {
    return str
      .replace(/[\s-_]+(.)?/g, (_, c) => c ? c.toUpperCase() : '')
      .replace(/^[A-Z]/, c => c.toLowerCase());
  },
  
  /**
   * Convert a string to snake_case
   * @param {string} str - Input string
   * @returns {string} - snake_case string
   */
  snakeCase: (str) => {
    return str
      .replace(/[\s-]+/g, '_')
      .replace(/([a-z])([A-Z])/g, '$1_$2')
      .toLowerCase();
  },
  
  /**
   * Convert a string to kebab-case
   * @param {string} str - Input string
   * @returns {string} - kebab-case string
   */
  kebabCase: (str) => {
    return str
      .replace(/[\s_]+/g, '-')
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .toLowerCase();
  },
  
  /**
   * Slugify a string (convert to URL-friendly format)
   * @param {string} str - Input string
   * @returns {string} - Slugified string
   */
  slugify: (str) => {
    return str
      .toLowerCase()
      .replace(/[^\w\s-]/g, '') // Remove non-word chars
      .replace(/[\s_-]+/g, '-') // Replace spaces and underscores with hyphens
      .replace(/^-+|-+$/g, ''); // Remove leading/trailing hyphens
  },
};

// Export all utility functions
const utils = {
  formatDate,
  formatRelativeTime,
  truncateText,
  generateId,
  debounce,
  throttle,
  deepClone,
  isEmptyObject,
  formatNumber,
  getQueryParams,
  createUrlWithParams,
  storage,
  cookies,
  validateEmail,
  validatePassword,
  getInitials,
  stringToColor,
  arrayUtils,
  formatCurrency,
  getBrowserInfo,
  objectUtils,
  stringUtils,
};

export default utils;