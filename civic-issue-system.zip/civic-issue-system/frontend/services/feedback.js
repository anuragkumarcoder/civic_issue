/**
 * Feedback service for handling user feedback and reporting
 */

import api from './api';

/**
 * Submit general feedback about the application
 * @param {Object} feedbackData - Feedback data
 * @param {string} feedbackData.type - Feedback type (suggestion, bug, praise, other)
 * @param {string} feedbackData.content - Feedback content
 * @param {string} [feedbackData.email] - User email (optional for anonymous feedback)
 * @param {Object} [feedbackData.metadata] - Additional metadata
 * @returns {Promise<Object>} - Feedback submission response
 */
export const submitFeedback = async (feedbackData) => {
  try {
    const response = await api.post('/feedback', feedbackData);
    return response;
  } catch (error) {
    console.error('Submit feedback error:', error);
    throw error;
  }
};

/**
 * Report an issue (content moderation)
 * @param {Object} reportData - Report data
 * @param {string} reportData.type - Type of content being reported (issue, comment, user, etc.)
 * @param {string} reportData.contentId - ID of the content being reported
 * @param {string} reportData.reason - Reason for reporting
 * @param {string} [reportData.description] - Additional description
 * @returns {Promise<Object>} - Report submission response
 */
export const reportContent = async (reportData) => {
  try {
    const response = await api.post('/reports', reportData);
    return response;
  } catch (error) {
    console.error('Report content error:', error);
    throw error;
  }
};

/**
 * Get user's submitted feedback history
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Feedback history response
 */
export const getFeedbackHistory = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/user/feedback?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get feedback history error:', error);
    throw error;
  }
};

/**
 * Get user's submitted reports history
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Reports history response
 */
export const getReportsHistory = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/user/reports?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get reports history error:', error);
    throw error;
  }
};

/**
 * Submit a bug report with optional screenshot
 * @param {Object} bugData - Bug report data
 * @param {string} bugData.title - Bug title
 * @param {string} bugData.description - Bug description
 * @param {string} bugData.severity - Bug severity (low, medium, high, critical)
 * @param {string} bugData.browserInfo - Browser information
 * @param {File} [bugData.screenshot] - Screenshot file (optional)
 * @returns {Promise<Object>} - Bug report submission response
 */
export const submitBugReport = async (bugData) => {
  try {
    const formData = new FormData();
    
    // Add text fields
    formData.append('title', bugData.title);
    formData.append('description', bugData.description);
    formData.append('severity', bugData.severity);
    formData.append('browserInfo', bugData.browserInfo);
    
    // Add screenshot if provided
    if (bugData.screenshot) {
      formData.append('screenshot', bugData.screenshot);
    }
    
    const response = await api.postFormData('/feedback/bug', formData);
    return response;
  } catch (error) {
    console.error('Submit bug report error:', error);
    throw error;
  }
};

/**
 * Submit a feature request
 * @param {Object} featureData - Feature request data
 * @param {string} featureData.title - Feature title
 * @param {string} featureData.description - Feature description
 * @param {string} [featureData.useCase] - Use case for the feature
 * @param {string} [featureData.priority] - Requested priority (nice-to-have, important, critical)
 * @returns {Promise<Object>} - Feature request submission response
 */
export const submitFeatureRequest = async (featureData) => {
  try {
    const response = await api.post('/feedback/feature', featureData);
    return response;
  } catch (error) {
    console.error('Submit feature request error:', error);
    throw error;
  }
};

/**
 * Get all feedback (admin only)
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - All feedback response
 */
export const getAllFeedback = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 20,
      type = '',
      status = '',
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    if (type) queryParams.append('type', type);
    if (status) queryParams.append('status', status);
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/admin/feedback?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get all feedback error:', error);
    throw error;
  }
};

/**
 * Get all reports (admin only)
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - All reports response
 */
export const getAllReports = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 20,
      type = '',
      status = '',
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    if (type) queryParams.append('type', type);
    if (status) queryParams.append('status', status);
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/admin/reports?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get all reports error:', error);
    throw error;
  }
};

/**
 * Update feedback status (admin only)
 * @param {string} feedbackId - Feedback ID
 * @param {Object} statusData - Status update data
 * @param {string} statusData.status - New status (pending, in-review, resolved, rejected)
 * @param {string} [statusData.adminNote] - Admin note
 * @returns {Promise<Object>} - Update status response
 */
export const updateFeedbackStatus = async (feedbackId, statusData) => {
  try {
    const response = await api.put(`/admin/feedback/${feedbackId}/status`, statusData);
    return response;
  } catch (error) {
    console.error(`Update feedback #${feedbackId} status error:`, error);
    throw error;
  }
};

/**
 * Update report status (admin only)
 * @param {string} reportId - Report ID
 * @param {Object} statusData - Status update data
 * @param {string} statusData.status - New status (pending, in-review, resolved, rejected)
 * @param {string} [statusData.adminNote] - Admin note
 * @param {boolean} [statusData.takeAction] - Whether to take action on reported content
 * @returns {Promise<Object>} - Update status response
 */
export const updateReportStatus = async (reportId, statusData) => {
  try {
    const response = await api.put(`/admin/reports/${reportId}/status`, statusData);
    return response;
  } catch (error) {
    console.error(`Update report #${reportId} status error:`, error);
    throw error;
  }
};

// Export all feedback and reporting functions
const feedbackService = {
  submitFeedback,
  reportContent,
  getFeedbackHistory,
  getReportsHistory,
  submitBugReport,
  submitFeatureRequest,
  getAllFeedback,
  getAllReports,
  updateFeedbackStatus,
  updateReportStatus,
};

export default feedbackService;