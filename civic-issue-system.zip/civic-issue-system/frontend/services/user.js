/**
 * User service for handling user profile and preferences
 */

import api from './api';

/**
 * Get current user profile
 * @returns {Promise<Object>} - User profile response
 */
export const getCurrentUserProfile = async () => {
  try {
    const response = await api.get('/user/profile');
    return response;
  } catch (error) {
    console.error('Get current user profile error:', error);
    throw error;
  }
};

/**
 * Get user profile by ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} - User profile response
 */
export const getUserProfile = async (userId) => {
  try {
    const response = await api.get(`/users/${userId}`);
    return response;
  } catch (error) {
    console.error(`Get user #${userId} profile error:`, error);
    throw error;
  }
};

/**
 * Update user profile
 * @param {Object} profileData - Profile data to update
 * @returns {Promise<Object>} - Update profile response
 */
export const updateUserProfile = async (profileData) => {
  try {
    const response = await api.put('/user/profile', profileData);
    return response;
  } catch (error) {
    console.error('Update user profile error:', error);
    throw error;
  }
};

/**
 * Upload user avatar
 * @param {File} avatarFile - Avatar image file
 * @returns {Promise<Object>} - Upload avatar response
 */
export const uploadUserAvatar = async (avatarFile) => {
  try {
    const formData = new FormData();
    formData.append('avatar', avatarFile);
    
    const response = await api.postFormData('/user/avatar', formData);
    return response;
  } catch (error) {
    console.error('Upload user avatar error:', error);
    throw error;
  }
};

/**
 * Delete user avatar
 * @returns {Promise<Object>} - Delete avatar response
 */
export const deleteUserAvatar = async () => {
  try {
    const response = await api.delete('/user/avatar');
    return response;
  } catch (error) {
    console.error('Delete user avatar error:', error);
    throw error;
  }
};

/**
 * Get user notification preferences
 * @returns {Promise<Object>} - Notification preferences response
 */
export const getNotificationPreferences = async () => {
  try {
    const response = await api.get('/user/preferences/notifications');
    return response;
  } catch (error) {
    console.error('Get notification preferences error:', error);
    throw error;
  }
};

/**
 * Update user notification preferences
 * @param {Object} preferences - Notification preferences
 * @returns {Promise<Object>} - Update preferences response
 */
export const updateNotificationPreferences = async (preferences) => {
  try {
    const response = await api.put('/user/preferences/notifications', preferences);
    return response;
  } catch (error) {
    console.error('Update notification preferences error:', error);
    throw error;
  }
};

/**
 * Get user privacy settings
 * @returns {Promise<Object>} - Privacy settings response
 */
export const getPrivacySettings = async () => {
  try {
    const response = await api.get('/user/preferences/privacy');
    return response;
  } catch (error) {
    console.error('Get privacy settings error:', error);
    throw error;
  }
};

/**
 * Update user privacy settings
 * @param {Object} settings - Privacy settings
 * @returns {Promise<Object>} - Update settings response
 */
export const updatePrivacySettings = async (settings) => {
  try {
    const response = await api.put('/user/preferences/privacy', settings);
    return response;
  } catch (error) {
    console.error('Update privacy settings error:', error);
    throw error;
  }
};

/**
 * Get user's issues
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - User issues response
 */
export const getUserIssues = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
      status = '',
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    if (status) queryParams.append('status', status);
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/user/issues?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get user issues error:', error);
    throw error;
  }
};

/**
 * Get user's comments
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - User comments response
 */
export const getUserComments = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/user/comments?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get user comments error:', error);
    throw error;
  }
};

/**
 * Get user's upvoted issues
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Upvoted issues response
 */
export const getUserUpvotedIssues = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/user/upvoted?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get user upvoted issues error:', error);
    throw error;
  }
};

/**
 * Get user's saved/bookmarked issues
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Saved issues response
 */
export const getUserSavedIssues = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/user/saved?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get user saved issues error:', error);
    throw error;
  }
};

/**
 * Save/bookmark an issue
 * @param {string} issueId - Issue ID
 * @returns {Promise<Object>} - Save issue response
 */
export const saveIssue = async (issueId) => {
  try {
    const response = await api.post(`/user/saved/${issueId}`);
    return response;
  } catch (error) {
    console.error(`Save issue #${issueId} error:`, error);
    throw error;
  }
};

/**
 * Unsave/unbookmark an issue
 * @param {string} issueId - Issue ID
 * @returns {Promise<Object>} - Unsave issue response
 */
export const unsaveIssue = async (issueId) => {
  try {
    const response = await api.delete(`/user/saved/${issueId}`);
    return response;
  } catch (error) {
    console.error(`Unsave issue #${issueId} error:`, error);
    throw error;
  }
};

/**
 * Get user activity
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - User activity response
 */
export const getUserActivity = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 20,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/user/activity?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get user activity error:', error);
    throw error;
  }
};

/**
 * Get user statistics
 * @returns {Promise<Object>} - User statistics response
 */
export const getUserStatistics = async () => {
  try {
    const response = await api.get('/user/statistics');
    return response;
  } catch (error) {
    console.error('Get user statistics error:', error);
    throw error;
  }
};

/**
 * Follow a user
 * @param {string} userId - User ID to follow
 * @returns {Promise<Object>} - Follow user response
 */
export const followUser = async (userId) => {
  try {
    const response = await api.post(`/user/following/${userId}`);
    return response;
  } catch (error) {
    console.error(`Follow user #${userId} error:`, error);
    throw error;
  }
};

/**
 * Unfollow a user
 * @param {string} userId - User ID to unfollow
 * @returns {Promise<Object>} - Unfollow user response
 */
export const unfollowUser = async (userId) => {
  try {
    const response = await api.delete(`/user/following/${userId}`);
    return response;
  } catch (error) {
    console.error(`Unfollow user #${userId} error:`, error);
    throw error;
  }
};

/**
 * Get user's followers
 * @param {string} userId - User ID
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Followers response
 */
export const getUserFollowers = async (userId, params = {}) => {
  try {
    const {
      page = 1,
      limit = 20,
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/users/${userId}/followers?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error(`Get user #${userId} followers error:`, error);
    throw error;
  }
};

/**
 * Get users that a user is following
 * @param {string} userId - User ID
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Following response
 */
export const getUserFollowing = async (userId, params = {}) => {
  try {
    const {
      page = 1,
      limit = 20,
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/users/${userId}/following?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error(`Get user #${userId} following error:`, error);
    throw error;
  }
};

// Export all user-related functions
const userService = {
  getCurrentUserProfile,
  getUserProfile,
  updateUserProfile,
  uploadUserAvatar,
  deleteUserAvatar,
  getNotificationPreferences,
  updateNotificationPreferences,
  getPrivacySettings,
  updatePrivacySettings,
  getUserIssues,
  getUserComments,
  getUserUpvotedIssues,
  getUserSavedIssues,
  saveIssue,
  unsaveIssue,
  getUserActivity,
  getUserStatistics,
  followUser,
  unfollowUser,
  getUserFollowers,
  getUserFollowing,
};

export default userService;