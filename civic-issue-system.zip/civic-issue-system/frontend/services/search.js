/**
 * Search service for handling search functionality
 */

import api from './api';

/**
 * Search issues with various filters
 * @param {Object} params - Search parameters
 * @returns {Promise<Object>} - Search results
 */
export const searchIssues = async (params = {}) => {
  try {
    const {
      query = '',
      category = '',
      status = '',
      priority = '',
      location = '',
      radius = 0,
      latitude = null,
      longitude = null,
      sortBy = 'createdAt',
      sortOrder = 'desc',
      page = 1,
      limit = 10,
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    
    if (query) queryParams.append('query', query);
    if (category) queryParams.append('category', category);
    if (status) queryParams.append('status', status);
    if (priority) queryParams.append('priority', priority);
    if (location) queryParams.append('location', location);
    if (radius > 0) queryParams.append('radius', radius.toString());
    if (latitude !== null) queryParams.append('latitude', latitude.toString());
    if (longitude !== null) queryParams.append('longitude', longitude.toString());
    if (sortBy) queryParams.append('sortBy', sortBy);
    if (sortOrder) queryParams.append('sortOrder', sortOrder);
    if (page) queryParams.append('page', page.toString());
    if (limit) queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/issues/search?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Search issues error:', error);
    throw error;
  }
};

/**
 * Search issues by location
 * @param {number} latitude - Latitude
 * @param {number} longitude - Longitude
 * @param {number} radius - Search radius in kilometers
 * @param {Object} additionalParams - Additional search parameters
 * @returns {Promise<Object>} - Search results
 */
export const searchIssuesByLocation = async (latitude, longitude, radius = 5, additionalParams = {}) => {
  return searchIssues({
    latitude,
    longitude,
    radius,
    ...additionalParams,
  });
};

/**
 * Search issues by text query
 * @param {string} query - Search query
 * @param {Object} additionalParams - Additional search parameters
 * @returns {Promise<Object>} - Search results
 */
export const searchIssuesByText = async (query, additionalParams = {}) => {
  return searchIssues({
    query,
    ...additionalParams,
  });
};

/**
 * Search issues by category
 * @param {string} category - Category ID or name
 * @param {Object} additionalParams - Additional search parameters
 * @returns {Promise<Object>} - Search results
 */
export const searchIssuesByCategory = async (category, additionalParams = {}) => {
  return searchIssues({
    category,
    ...additionalParams,
  });
};

/**
 * Search issues by status
 * @param {string} status - Issue status
 * @param {Object} additionalParams - Additional search parameters
 * @returns {Promise<Object>} - Search results
 */
export const searchIssuesByStatus = async (status, additionalParams = {}) => {
  return searchIssues({
    status,
    ...additionalParams,
  });
};

/**
 * Search issues by priority
 * @param {string} priority - Issue priority
 * @param {Object} additionalParams - Additional search parameters
 * @returns {Promise<Object>} - Search results
 */
export const searchIssuesByPriority = async (priority, additionalParams = {}) => {
  return searchIssues({
    priority,
    ...additionalParams,
  });
};

/**
 * Search users
 * @param {Object} params - Search parameters
 * @returns {Promise<Object>} - Search results
 */
export const searchUsers = async (params = {}) => {
  try {
    const {
      query = '',
      role = '',
      status = '',
      sortBy = 'createdAt',
      sortOrder = 'desc',
      page = 1,
      limit = 10,
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    
    if (query) queryParams.append('query', query);
    if (role) queryParams.append('role', role);
    if (status) queryParams.append('status', status);
    if (sortBy) queryParams.append('sortBy', sortBy);
    if (sortOrder) queryParams.append('sortOrder', sortOrder);
    if (page) queryParams.append('page', page.toString());
    if (limit) queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/admin/users/search?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Search users error:', error);
    throw error;
  }
};

/**
 * Get search suggestions based on partial query
 * @param {string} query - Partial search query
 * @param {string} type - Suggestion type ('issues', 'locations', 'categories')
 * @param {number} limit - Maximum number of suggestions
 * @returns {Promise<Array>} - Search suggestions
 */
export const getSearchSuggestions = async (query, type = 'issues', limit = 5) => {
  try {
    if (!query || query.length < 2) {
      return [];
    }
    
    const queryParams = new URLSearchParams({
      query,
      type,
      limit: limit.toString(),
    });
    
    const response = await api.get(`/search/suggestions?${queryParams.toString()}`);
    return response.suggestions || [];
  } catch (error) {
    console.error('Get search suggestions error:', error);
    return [];
  }
};

/**
 * Get trending search terms
 * @param {string} type - Term type ('issues', 'locations', 'categories')
 * @param {number} limit - Maximum number of terms
 * @returns {Promise<Array>} - Trending search terms
 */
export const getTrendingSearchTerms = async (type = 'issues', limit = 5) => {
  try {
    const queryParams = new URLSearchParams({
      type,
      limit: limit.toString(),
    });
    
    const response = await api.get(`/search/trending?${queryParams.toString()}`);
    return response.terms || [];
  } catch (error) {
    console.error('Get trending search terms error:', error);
    return [];
  }
};

/**
 * Save search query to user's search history
 * @param {string} query - Search query
 * @param {string} type - Search type
 * @returns {Promise<Object>} - Save response
 */
export const saveSearchQuery = async (query, type = 'issues') => {
  try {
    const response = await api.post('/search/history', { query, type });
    return response;
  } catch (error) {
    console.error('Save search query error:', error);
    // Don't throw error for non-critical operation
    return { success: false };
  }
};

/**
 * Get user's search history
 * @param {string} type - Search type
 * @param {number} limit - Maximum number of history items
 * @returns {Promise<Array>} - Search history
 */
export const getSearchHistory = async (type = 'issues', limit = 10) => {
  try {
    const queryParams = new URLSearchParams({
      type,
      limit: limit.toString(),
    });
    
    const response = await api.get(`/search/history?${queryParams.toString()}`);
    return response.history || [];
  } catch (error) {
    console.error('Get search history error:', error);
    return [];
  }
};

/**
 * Clear user's search history
 * @param {string} type - Search type (optional, clears all if not specified)
 * @returns {Promise<Object>} - Clear response
 */
export const clearSearchHistory = async (type = null) => {
  try {
    const queryParams = new URLSearchParams();
    if (type) queryParams.append('type', type);
    
    const endpoint = queryParams.toString()
      ? `/search/history?${queryParams.toString()}`
      : '/search/history';
    
    const response = await api.delete(endpoint);
    return response;
  } catch (error) {
    console.error('Clear search history error:', error);
    throw error;
  }
};

// Export all search functions
const searchService = {
  searchIssues,
  searchIssuesByLocation,
  searchIssuesByText,
  searchIssuesByCategory,
  searchIssuesByStatus,
  searchIssuesByPriority,
  searchUsers,
  getSearchSuggestions,
  getTrendingSearchTerms,
  saveSearchQuery,
  getSearchHistory,
  clearSearchHistory,
};

export default searchService;