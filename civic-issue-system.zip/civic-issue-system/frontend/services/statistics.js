/**
 * Statistics service for handling application metrics and statistics
 */

import api from './api';

/**
 * Get overall system statistics
 * @returns {Promise<Object>} - System statistics response
 */
export const getSystemStatistics = async () => {
  try {
    const response = await api.get('/statistics/system');
    return response;
  } catch (error) {
    console.error('Get system statistics error:', error);
    throw error;
  }
};

/**
 * Get issue statistics
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Issue statistics response
 */
export const getIssueStatistics = async (params = {}) => {
  try {
    const {
      timeframe = 'all', // all, week, month, year
      groupBy = 'status', // status, category, priority, etc.
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('timeframe', timeframe);
    queryParams.append('groupBy', groupBy);
    
    const response = await api.get(`/statistics/issues?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get issue statistics error:', error);
    throw error;
  }
};

/**
 * Get user activity statistics
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - User activity statistics response
 */
export const getUserActivityStatistics = async (params = {}) => {
  try {
    const {
      timeframe = 'month', // day, week, month, year
      metric = 'active_users', // active_users, new_users, etc.
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('timeframe', timeframe);
    queryParams.append('metric', metric);
    
    const response = await api.get(`/statistics/users?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get user activity statistics error:', error);
    throw error;
  }
};

/**
 * Get geographic distribution of issues
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Geographic statistics response
 */
export const getGeographicStatistics = async (params = {}) => {
  try {
    const {
      level = 'city', // city, state, country
      limit = 10,
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('level', level);
    queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/statistics/geographic?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get geographic statistics error:', error);
    throw error;
  }
};

/**
 * Get resolution time statistics
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Resolution time statistics response
 */
export const getResolutionTimeStatistics = async (params = {}) => {
  try {
    const {
      timeframe = 'month', // week, month, quarter, year
      groupBy = 'category', // category, priority, etc.
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('timeframe', timeframe);
    queryParams.append('groupBy', groupBy);
    
    const response = await api.get(`/statistics/resolution-time?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get resolution time statistics error:', error);
    throw error;
  }
};

/**
 * Get trending issues statistics
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Trending issues statistics response
 */
export const getTrendingIssuesStatistics = async (params = {}) => {
  try {
    const {
      timeframe = 'week', // day, week, month
      limit = 5,
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('timeframe', timeframe);
    queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/statistics/trending?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get trending issues statistics error:', error);
    throw error;
  }
};

/**
 * Get user engagement statistics
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - User engagement statistics response
 */
export const getUserEngagementStatistics = async (params = {}) => {
  try {
    const {
      timeframe = 'month', // week, month, quarter, year
      metric = 'comments', // comments, upvotes, etc.
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('timeframe', timeframe);
    queryParams.append('metric', metric);
    
    const response = await api.get(`/statistics/engagement?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get user engagement statistics error:', error);
    throw error;
  }
};

/**
 * Get category distribution statistics
 * @returns {Promise<Object>} - Category distribution statistics response
 */
export const getCategoryDistributionStatistics = async () => {
  try {
    const response = await api.get('/statistics/categories');
    return response;
  } catch (error) {
    console.error('Get category distribution statistics error:', error);
    throw error;
  }
};

/**
 * Get status distribution statistics
 * @returns {Promise<Object>} - Status distribution statistics response
 */
export const getStatusDistributionStatistics = async () => {
  try {
    const response = await api.get('/statistics/statuses');
    return response;
  } catch (error) {
    console.error('Get status distribution statistics error:', error);
    throw error;
  }
};

/**
 * Get time-based statistics
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Time-based statistics response
 */
export const getTimeBasedStatistics = async (params = {}) => {
  try {
    const {
      metric = 'issues', // issues, comments, users
      interval = 'day', // hour, day, week, month
      startDate = '',
      endDate = '',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('metric', metric);
    queryParams.append('interval', interval);
    if (startDate) queryParams.append('startDate', startDate);
    if (endDate) queryParams.append('endDate', endDate);
    
    const response = await api.get(`/statistics/time-series?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get time-based statistics error:', error);
    throw error;
  }
};

/**
 * Get comparative statistics between two time periods
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Comparative statistics response
 */
export const getComparativeStatistics = async (params = {}) => {
  try {
    const {
      metric = 'issues', // issues, comments, users
      currentPeriodStart = '',
      currentPeriodEnd = '',
      previousPeriodStart = '',
      previousPeriodEnd = '',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('metric', metric);
    queryParams.append('currentPeriodStart', currentPeriodStart);
    queryParams.append('currentPeriodEnd', currentPeriodEnd);
    queryParams.append('previousPeriodStart', previousPeriodStart);
    queryParams.append('previousPeriodEnd', previousPeriodEnd);
    
    const response = await api.get(`/statistics/comparative?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get comparative statistics error:', error);
    throw error;
  }
};

// Export all statistics-related functions
const statisticsService = {
  getSystemStatistics,
  getIssueStatistics,
  getUserActivityStatistics,
  getGeographicStatistics,
  getResolutionTimeStatistics,
  getTrendingIssuesStatistics,
  getUserEngagementStatistics,
  getCategoryDistributionStatistics,
  getStatusDistributionStatistics,
  getTimeBasedStatistics,
  getComparativeStatistics,
};

export default statisticsService;