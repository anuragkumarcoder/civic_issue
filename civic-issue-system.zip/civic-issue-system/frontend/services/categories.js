/**
 * Categories service for handling category-related API calls
 */

import api from './api';

/**
 * Get all categories
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Categories response
 */
export const getCategories = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 50,
      sortBy = 'name',
      sortOrder = 'asc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/categories?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get categories error:', error);
    throw error;
  }
};

/**
 * Get a specific category
 * @param {string} categoryId - Category ID
 * @returns {Promise<Object>} - Category response
 */
export const getCategory = async (categoryId) => {
  try {
    const response = await api.get(`/categories/${categoryId}`);
    return response;
  } catch (error) {
    console.error(`Get category #${categoryId} error:`, error);
    throw error;
  }
};

/**
 * Create a new category (admin only)
 * @param {Object} categoryData - Category data
 * @returns {Promise<Object>} - Create category response
 */
export const createCategory = async (categoryData) => {
  try {
    const response = await api.post('/admin/categories', categoryData);
    return response;
  } catch (error) {
    console.error('Create category error:', error);
    throw error;
  }
};

/**
 * Update a category (admin only)
 * @param {string} categoryId - Category ID
 * @param {Object} categoryData - Updated category data
 * @returns {Promise<Object>} - Update category response
 */
export const updateCategory = async (categoryId, categoryData) => {
  try {
    const response = await api.put(`/admin/categories/${categoryId}`, categoryData);
    return response;
  } catch (error) {
    console.error(`Update category #${categoryId} error:`, error);
    throw error;
  }
};

/**
 * Delete a category (admin only)
 * @param {string} categoryId - Category ID
 * @returns {Promise<Object>} - Delete category response
 */
export const deleteCategory = async (categoryId) => {
  try {
    const response = await api.delete(`/admin/categories/${categoryId}`);
    return response;
  } catch (error) {
    console.error(`Delete category #${categoryId} error:`, error);
    throw error;
  }
};

/**
 * Get category statistics
 * @returns {Promise<Object>} - Category statistics response
 */
export const getCategoryStatistics = async () => {
  try {
    const response = await api.get('/categories/statistics');
    return response;
  } catch (error) {
    console.error('Get category statistics error:', error);
    throw error;
  }
};

/**
 * Get issues by category
 * @param {string} categoryId - Category ID
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Issues response
 */
export const getIssuesByCategory = async (categoryId, params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
      status = '',
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    if (status) queryParams.append('status', status);
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/categories/${categoryId}/issues?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error(`Get issues for category #${categoryId} error:`, error);
    throw error;
  }
};

/**
 * Upload a category icon (admin only)
 * @param {string} categoryId - Category ID
 * @param {File} iconFile - Icon file
 * @returns {Promise<Object>} - Upload icon response
 */
export const uploadCategoryIcon = async (categoryId, iconFile) => {
  try {
    const formData = new FormData();
    formData.append('icon', iconFile);
    
    const response = await api.postFormData(`/admin/categories/${categoryId}/icon`, formData);
    return response;
  } catch (error) {
    console.error(`Upload icon for category #${categoryId} error:`, error);
    throw error;
  }
};

/**
 * Get trending categories
 * @param {number} limit - Maximum number of categories
 * @returns {Promise<Object>} - Trending categories response
 */
export const getTrendingCategories = async (limit = 5) => {
  try {
    const queryParams = new URLSearchParams();
    queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/categories/trending?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get trending categories error:', error);
    throw error;
  }
};

/**
 * Reorder categories (admin only)
 * @param {Array} categoryOrder - Array of category IDs in desired order
 * @returns {Promise<Object>} - Reorder response
 */
export const reorderCategories = async (categoryOrder) => {
  try {
    const response = await api.put('/admin/categories/reorder', { categoryOrder });
    return response;
  } catch (error) {
    console.error('Reorder categories error:', error);
    throw error;
  }
};

// Export all category-related functions
const categoryService = {
  getCategories,
  getCategory,
  createCategory,
  updateCategory,
  deleteCategory,
  getCategoryStatistics,
  getIssuesByCategory,
  uploadCategoryIcon,
  getTrendingCategories,
  reorderCategories,
};

export default categoryService;