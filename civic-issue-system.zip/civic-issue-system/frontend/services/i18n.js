/**
 * Internationalization (i18n) service for handling translations and localization
 */

import api from './api';

// Default language
const DEFAULT_LANGUAGE = 'en';

// Available languages
const AVAILABLE_LANGUAGES = {
  en: { name: 'English', nativeName: 'English' },
  es: { name: 'Spanish', nativeName: 'Español' },
  fr: { name: 'French', nativeName: 'Français' },
  de: { name: 'German', nativeName: 'Deutsch' },
  zh: { name: 'Chinese', nativeName: '中文' },
};

// Store translations
let translations = {};

// Current language
let currentLanguage = DEFAULT_LANGUAGE;

/**
 * Initialize i18n service
 * @param {string} language - Initial language
 * @returns {Promise<Object>} - Initialization result
 */
export const initialize = async (language = DEFAULT_LANGUAGE) => {
  try {
    // Set language from localStorage if available
    const storedLanguage = localStorage.getItem('language');
    const initialLanguage = storedLanguage || language || DEFAULT_LANGUAGE;
    
    // Load translations for the initial language
    await loadTranslations(initialLanguage);
    
    // Set current language
    currentLanguage = initialLanguage;
    localStorage.setItem('language', currentLanguage);
    
    // Set HTML lang attribute
    document.documentElement.lang = currentLanguage;
    
    return { success: true, language: currentLanguage };
  } catch (error) {
    console.error('Error initializing i18n:', error);
    return { success: false, error };
  }
};

/**
 * Load translations for a language
 * @param {string} language - Language code
 * @returns {Promise<Object>} - Translations
 */
export const loadTranslations = async (language) => {
  try {
    // Check if translations are already loaded
    if (translations[language]) {
      return translations[language];
    }
    
    // Load translations from API or static files
    const response = await fetch(`/locales/${language}.json`);
    
    if (!response.ok) {
      throw new Error(`Failed to load translations for ${language}`);
    }
    
    const data = await response.json();
    translations[language] = data;
    
    return data;
  } catch (error) {
    console.error(`Error loading translations for ${language}:`, error);
    
    // Fallback to default language
    if (language !== DEFAULT_LANGUAGE) {
      console.warn(`Falling back to ${DEFAULT_LANGUAGE} translations`);
      return loadTranslations(DEFAULT_LANGUAGE);
    }
    
    // If default language fails, return empty object
    return {};
  }
};

/**
 * Change language
 * @param {string} language - Language code
 * @returns {Promise<Object>} - Change result
 */
export const changeLanguage = async (language) => {
  try {
    // Check if language is available
    if (!AVAILABLE_LANGUAGES[language]) {
      throw new Error(`Language ${language} is not available`);
    }
    
    // Load translations for the new language
    await loadTranslations(language);
    
    // Set current language
    currentLanguage = language;
    localStorage.setItem('language', currentLanguage);
    
    // Set HTML lang attribute
    document.documentElement.lang = currentLanguage;
    
    // Dispatch language change event
    window.dispatchEvent(new CustomEvent('languagechange', { detail: { language } }));
    
    return { success: true, language: currentLanguage };
  } catch (error) {
    console.error(`Error changing language to ${language}:`, error);
    return { success: false, error };
  }
};

/**
 * Get current language
 * @returns {string} - Current language code
 */
export const getCurrentLanguage = () => {
  return currentLanguage;
};

/**
 * Get available languages
 * @returns {Object} - Available languages
 */
export const getAvailableLanguages = () => {
  return AVAILABLE_LANGUAGES;
};

/**
 * Translate a key
 * @param {string} key - Translation key
 * @param {Object} params - Parameters for interpolation
 * @param {string} language - Language code (optional, defaults to current language)
 * @returns {string} - Translated text
 */
export const translate = (key, params = {}, language = currentLanguage) => {
  // Get translations for the language
  const languageTranslations = translations[language] || {};
  
  // Get translation for the key
  let translation = getNestedTranslation(languageTranslations, key);
  
  // Fallback to default language if translation is not found
  if (!translation && language !== DEFAULT_LANGUAGE) {
    const defaultTranslations = translations[DEFAULT_LANGUAGE] || {};
    translation = getNestedTranslation(defaultTranslations, key);
  }
  
  // Fallback to key if translation is still not found
  if (!translation) {
    translation = key;
  }
  
  // Interpolate parameters
  return interpolate(translation, params);
};

/**
 * Get nested translation
 * @param {Object} obj - Translations object
 * @param {string} path - Nested path (e.g., 'common.buttons.submit')
 * @returns {string|null} - Translation or null if not found
 */
const getNestedTranslation = (obj, path) => {
  const keys = path.split('.');
  let current = obj;
  
  for (const key of keys) {
    if (current === undefined || current === null) {
      return null;
    }
    
    current = current[key];
  }
  
  return current;
};

/**
 * Interpolate parameters in translation
 * @param {string} text - Translation text with placeholders
 * @param {Object} params - Parameters for interpolation
 * @returns {string} - Interpolated text
 */
const interpolate = (text, params) => {
  if (typeof text !== 'string') {
    return text;
  }
  
  return text.replace(/{{\s*([\w.]+)\s*}}/g, (match, key) => {
    const value = params[key];
    return value !== undefined ? value : match;
  });
};

/**
 * Format date according to current locale
 * @param {Date|string|number} date - Date to format
 * @param {Object} options - Intl.DateTimeFormat options
 * @returns {string} - Formatted date
 */
export const formatDate = (date, options = {}) => {
  const dateObj = new Date(date);
  
  const defaultOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  };
  
  const mergedOptions = { ...defaultOptions, ...options };
  
  return new Intl.DateTimeFormat(currentLanguage, mergedOptions).format(dateObj);
};

/**
 * Format number according to current locale
 * @param {number} number - Number to format
 * @param {Object} options - Intl.NumberFormat options
 * @returns {string} - Formatted number
 */
export const formatNumber = (number, options = {}) => {
  return new Intl.NumberFormat(currentLanguage, options).format(number);
};

/**
 * Format currency according to current locale
 * @param {number} amount - Amount to format
 * @param {string} currency - Currency code (e.g., 'USD', 'EUR')
 * @param {Object} options - Additional Intl.NumberFormat options
 * @returns {string} - Formatted currency
 */
export const formatCurrency = (amount, currency = 'USD', options = {}) => {
  const defaultOptions = {
    style: 'currency',
    currency,
  };
  
  const mergedOptions = { ...defaultOptions, ...options };
  
  return new Intl.NumberFormat(currentLanguage, mergedOptions).format(amount);
};

/**
 * Format relative time according to current locale
 * @param {Date|string|number} date - Date to format
 * @param {Object} options - Additional options
 * @returns {string} - Formatted relative time
 */
export const formatRelativeTime = (date, options = {}) => {
  const dateObj = new Date(date);
  const now = new Date();
  
  const diffInSeconds = Math.floor((now - dateObj) / 1000);
  
  const units = [
    { unit: 'year', seconds: 31536000 },
    { unit: 'month', seconds: 2592000 },
    { unit: 'day', seconds: 86400 },
    { unit: 'hour', seconds: 3600 },
    { unit: 'minute', seconds: 60 },
    { unit: 'second', seconds: 1 },
  ];
  
  for (const { unit, seconds } of units) {
    const value = Math.floor(diffInSeconds / seconds);
    
    if (value >= 1) {
      const rtf = new Intl.RelativeTimeFormat(currentLanguage, {
        numeric: 'auto',
        ...options,
      });
      
      return rtf.format(-value, unit);
    }
  }
  
  // Fallback for "just now"
  return translate('common.time.justNow');
};

/**
 * Get direction (ltr or rtl) for current language
 * @returns {string} - Text direction ('ltr' or 'rtl')
 */
export const getDirection = () => {
  const rtlLanguages = ['ar', 'he', 'fa', 'ur'];
  return rtlLanguages.includes(currentLanguage) ? 'rtl' : 'ltr';
};

/**
 * Get user preferred languages from browser
 * @returns {Array<string>} - Preferred languages
 */
export const getBrowserLanguages = () => {
  if (typeof navigator === 'undefined') {
    return [DEFAULT_LANGUAGE];
  }
  
  const languages = navigator.languages || [navigator.language || navigator.userLanguage];
  
  return languages.map(lang => lang.split('-')[0]);
};

/**
 * Detect best language for user
 * @returns {string} - Best matching language
 */
export const detectBestLanguage = () => {
  const browserLanguages = getBrowserLanguages();
  
  // Find first matching language
  for (const lang of browserLanguages) {
    if (AVAILABLE_LANGUAGES[lang]) {
      return lang;
    }
  }
  
  // Fallback to default language
  return DEFAULT_LANGUAGE;
};

/**
 * Update user language preference on server
 * @param {string} language - Language code
 * @returns {Promise<Object>} - Update result
 */
export const updateUserLanguagePreference = async (language) => {
  try {
    const response = await api.put('/user/preferences/language', { language });
    return response;
  } catch (error) {
    console.error('Error updating user language preference:', error);
    throw error;
  }
};

// Export all i18n-related functions
const i18nService = {
  initialize,
  loadTranslations,
  changeLanguage,
  getCurrentLanguage,
  getAvailableLanguages,
  translate,
  formatDate,
  formatNumber,
  formatCurrency,
  formatRelativeTime,
  getDirection,
  getBrowserLanguages,
  detectBestLanguage,
  updateUserLanguagePreference,
};

// Shorthand for translate function
export const t = translate;

export default i18nService;