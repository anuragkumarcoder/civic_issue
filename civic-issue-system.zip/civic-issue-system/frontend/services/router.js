/**
 * Router service for handling navigation and route management
 */

import permissionsService from './permissions';

// Store route history
let routeHistory = [];

// Maximum history size
const MAX_HISTORY_SIZE = 20;

/**
 * Initialize router service
 * @param {Object} router - Router instance (e.g., Next.js router)
 * @returns {Object} - Initialization result
 */
export const initialize = (router) => {
  try {
    if (!router) {
      throw new Error('Router instance is required');
    }
    
    // Store router instance
    window.__routerInstance = router;
    
    // Set up route change listeners
    setupRouteChangeListeners(router);
    
    return { success: true };
  } catch (error) {
    console.error('Error initializing router service:', error);
    return { success: false, error };
  }
};

/**
 * Set up route change listeners
 * @param {Object} router - Router instance
 */
const setupRouteChangeListeners = (router) => {
  // Listen for route changes
  router.events?.on('routeChangeStart', handleRouteChangeStart);
  router.events?.on('routeChangeComplete', handleRouteChangeComplete);
  router.events?.on('routeChangeError', handleRouteChangeError);
};

/**
 * Handle route change start
 * @param {string} url - Destination URL
 */
const handleRouteChangeStart = (url) => {
  // Dispatch route change start event
  window.dispatchEvent(new CustomEvent('routeChangeStart', { detail: { url } }));
};

/**
 * Handle route change complete
 * @param {string} url - Current URL
 */
const handleRouteChangeComplete = (url) => {
  // Add to route history
  addToRouteHistory(url);
  
  // Dispatch route change complete event
  window.dispatchEvent(new CustomEvent('routeChangeComplete', { detail: { url } }));
};

/**
 * Handle route change error
 * @param {Error} error - Route change error
 * @param {string} url - Destination URL
 */
const handleRouteChangeError = (error, url) => {
  // Dispatch route change error event
  window.dispatchEvent(new CustomEvent('routeChangeError', { detail: { error, url } }));
};

/**
 * Add URL to route history
 * @param {string} url - URL to add
 */
const addToRouteHistory = (url) => {
  // Don't add duplicate consecutive entries
  if (routeHistory.length > 0 && routeHistory[routeHistory.length - 1] === url) {
    return;
  }
  
  // Add to history
  routeHistory.push(url);
  
  // Limit history size
  if (routeHistory.length > MAX_HISTORY_SIZE) {
    routeHistory = routeHistory.slice(-MAX_HISTORY_SIZE);
  }
};

/**
 * Get route history
 * @returns {Array<string>} - Route history
 */
export const getRouteHistory = () => {
  return [...routeHistory];
};

/**
 * Get previous route
 * @returns {string|null} - Previous route or null if none
 */
export const getPreviousRoute = () => {
  if (routeHistory.length < 2) {
    return null;
  }
  
  return routeHistory[routeHistory.length - 2];
};

/**
 * Navigate to a route
 * @param {string} url - Destination URL
 * @param {Object} options - Navigation options
 * @returns {Promise<boolean>} - Whether navigation was successful
 */
export const navigateTo = async (url, options = {}) => {
  try {
    const router = window.__routerInstance;
    
    if (!router) {
      throw new Error('Router not initialized');
    }
    
    // Check if route requires authentication
    if (options.requiresAuth && !permissionsService.isAuthenticated()) {
      // Redirect to login with return URL
      const returnUrl = encodeURIComponent(url);
      await router.push(`/login?returnUrl=${returnUrl}`);
      return false;
    }
    
    // Navigate to URL
    await router.push(url, options.as, {
      shallow: options.shallow,
      locale: options.locale,
      scroll: options.scroll !== false,
    });
    
    return true;
  } catch (error) {
    console.error(`Error navigating to ${url}:`, error);
    return false;
  }
};

/**
 * Navigate back
 * @returns {Promise<boolean>} - Whether navigation was successful
 */
export const goBack = async () => {
  try {
    const router = window.__routerInstance;
    
    if (!router) {
      throw new Error('Router not initialized');
    }
    
    // Check if there's a previous route in history
    const previousRoute = getPreviousRoute();
    
    if (previousRoute) {
      // Navigate to previous route
      await router.push(previousRoute);
      return true;
    }
    
    // Fallback to browser history
    router.back();
    return true;
  } catch (error) {
    console.error('Error navigating back:', error);
    return false;
  }
};

/**
 * Replace current route
 * @param {string} url - Destination URL
 * @param {Object} options - Navigation options
 * @returns {Promise<boolean>} - Whether navigation was successful
 */
export const replaceRoute = async (url, options = {}) => {
  try {
    const router = window.__routerInstance;
    
    if (!router) {
      throw new Error('Router not initialized');
    }
    
    // Replace current route
    await router.replace(url, options.as, {
      shallow: options.shallow,
      locale: options.locale,
      scroll: options.scroll !== false,
    });
    
    return true;
  } catch (error) {
    console.error(`Error replacing route with ${url}:`, error);
    return false;
  }
};

/**
 * Get current route
 * @returns {Object} - Current route information
 */
export const getCurrentRoute = () => {
  const router = window.__routerInstance;
  
  if (!router) {
    return null;
  }
  
  return {
    pathname: router.pathname,
    query: router.query,
    asPath: router.asPath,
    locale: router.locale,
  };
};

/**
 * Check if a route is active
 * @param {string} path - Route path to check
 * @param {boolean} exact - Whether to match exactly
 * @returns {boolean} - Whether route is active
 */
export const isRouteActive = (path, exact = false) => {
  const router = window.__routerInstance;
  
  if (!router) {
    return false;
  }
  
  const currentPath = router.asPath.split('?')[0];
  
  if (exact) {
    return currentPath === path;
  }
  
  return currentPath.startsWith(path);
};

/**
 * Generate URL with query parameters
 * @param {string} baseUrl - Base URL
 * @param {Object} params - Query parameters
 * @returns {string} - URL with query parameters
 */
export const generateUrl = (baseUrl, params = {}) => {
  // Filter out undefined and null values
  const filteredParams = Object.entries(params)
    .filter(([_, value]) => value !== undefined && value !== null)
    .reduce((acc, [key, value]) => ({ ...acc, [key]: value }), {});
  
  // If no params, return base URL
  if (Object.keys(filteredParams).length === 0) {
    return baseUrl;
  }
  
  // Create URL object
  const url = new URL(baseUrl, window.location.origin);
  
  // Add query parameters
  Object.entries(filteredParams).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      // Handle array values
      value.forEach(item => url.searchParams.append(key, item));
    } else {
      url.searchParams.append(key, value);
    }
  });
  
  // Return URL string (remove origin for relative URLs)
  return url.toString().replace(window.location.origin, '');
};

/**
 * Parse query parameters from URL
 * @param {string} url - URL to parse
 * @returns {Object} - Parsed query parameters
 */
export const parseQueryParams = (url) => {
  try {
    // Create URL object
    const urlObj = new URL(url, window.location.origin);
    
    // Parse query parameters
    const params = {};
    urlObj.searchParams.forEach((value, key) => {
      // Check if parameter already exists
      if (params[key]) {
        // Convert to array if not already
        if (!Array.isArray(params[key])) {
          params[key] = [params[key]];
        }
        
        // Add new value
        params[key].push(value);
      } else {
        params[key] = value;
      }
    });
    
    return params;
  } catch (error) {
    console.error(`Error parsing query parameters from ${url}:`, error);
    return {};
  }
};

// Export all router-related functions
const routerService = {
  initialize,
  getRouteHistory,
  getPreviousRoute,
  navigateTo,
  goBack,
  replaceRoute,
  getCurrentRoute,
  isRouteActive,
  generateUrl,
  parseQueryParams,
};

export default routerService;