/**
 * Geolocation service for handling location-related functionality
 */

/**
 * Get the user's current position
 * @param {Object} options - Geolocation options
 * @returns {Promise<GeolocationPosition>} - Geolocation position
 */
export const getCurrentPosition = (options = {}) => {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by your browser'));
      return;
    }
    
    const defaultOptions = {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 0,
      ...options,
    };
    
    navigator.geolocation.getCurrentPosition(
      position => resolve(position),
      error => reject(error),
      defaultOptions
    );
  });
};

/**
 * Watch the user's position (continuous updates)
 * @param {Function} successCallback - Success callback
 * @param {Function} errorCallback - Error callback
 * @param {Object} options - Geolocation options
 * @returns {number} - Watch ID for clearWatch
 */
export const watchPosition = (successCallback, errorCallback, options = {}) => {
  if (!navigator.geolocation) {
    errorCallback(new Error('Geolocation is not supported by your browser'));
    return null;
  }
  
  const defaultOptions = {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0,
    ...options,
  };
  
  return navigator.geolocation.watchPosition(
    successCallback,
    errorCallback,
    defaultOptions
  );
};

/**
 * Stop watching the user's position
 * @param {number} watchId - Watch ID from watchPosition
 */
export const clearWatch = (watchId) => {
  if (!navigator.geolocation || watchId === null) {
    return;
  }
  
  navigator.geolocation.clearWatch(watchId);
};

/**
 * Calculate the distance between two coordinates in kilometers
 * @param {number} lat1 - Latitude of first point
 * @param {number} lon1 - Longitude of first point
 * @param {number} lat2 - Latitude of second point
 * @param {number} lon2 - Longitude of second point
 * @returns {number} - Distance in kilometers
 */
export const calculateDistance = (lat1, lon1, lat2, lon2) => {
  // Haversine formula
  const R = 6371; // Radius of the Earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // Distance in km
  
  return distance;
};

/**
 * Convert degrees to radians
 * @param {number} deg - Degrees
 * @returns {number} - Radians
 */
const deg2rad = (deg) => {
  return deg * (Math.PI / 180);
};

/**
 * Get a formatted address from coordinates using reverse geocoding
 * @param {number} latitude - Latitude
 * @param {number} longitude - Longitude
 * @returns {Promise<Object>} - Address information
 */
export const getAddressFromCoordinates = async (latitude, longitude) => {
  try {
    // Using Nominatim OpenStreetMap service for reverse geocoding
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
      {
        headers: {
          'Accept-Language': 'en-US,en;q=0.9',
          'User-Agent': 'CivicIssueTracker/1.0',
        },
      }
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch address');
    }
    
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Reverse geocoding error:', error);
    throw error;
  }
};

/**
 * Get coordinates from an address using geocoding
 * @param {string} address - Address to geocode
 * @returns {Promise<Object>} - Coordinates and address information
 */
export const getCoordinatesFromAddress = async (address) => {
  try {
    // Using Nominatim OpenStreetMap service for geocoding
    const encodedAddress = encodeURIComponent(address);
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodedAddress}&limit=1`,
      {
        headers: {
          'Accept-Language': 'en-US,en;q=0.9',
          'User-Agent': 'CivicIssueTracker/1.0',
        },
      }
    );
    
    if (!response.ok) {
      throw new Error('Failed to fetch coordinates');
    }
    
    const data = await response.json();
    
    if (data.length === 0) {
      throw new Error('No results found for this address');
    }
    
    return data[0];
  } catch (error) {
    console.error('Geocoding error:', error);
    throw error;
  }
};

/**
 * Format a location object into a readable address string
 * @param {Object} location - Location object
 * @returns {string} - Formatted address
 */
export const formatAddress = (location) => {
  if (!location) return '';
  
  // Handle OpenStreetMap Nominatim format
  if (location.address) {
    const address = location.address;
    const parts = [];
    
    if (address.road) parts.push(address.road);
    if (address.house_number) parts.push(address.house_number);
    if (address.suburb) parts.push(address.suburb);
    if (address.city || address.town || address.village) {
      parts.push(address.city || address.town || address.village);
    }
    if (address.state || address.county) {
      parts.push(address.state || address.county);
    }
    if (address.postcode) parts.push(address.postcode);
    if (address.country) parts.push(address.country);
    
    return parts.join(', ');
  }
  
  // Handle custom location object format
  if (typeof location === 'object') {
    const parts = [];
    
    if (location.street) parts.push(location.street);
    if (location.city) parts.push(location.city);
    if (location.state) parts.push(location.state);
    if (location.postalCode) parts.push(location.postalCode);
    if (location.country) parts.push(location.country);
    
    return parts.join(', ');
  }
  
  // If it's already a string, return it
  if (typeof location === 'string') {
    return location;
  }
  
  return '';
};

/**
 * Check if geolocation is supported in the current browser
 * @returns {boolean} - Whether geolocation is supported
 */
export const isGeolocationSupported = () => {
  return !!navigator && !!navigator.geolocation;
};

/**
 * Get a static map image URL for a location
 * @param {number} latitude - Latitude
 * @param {number} longitude - Longitude
 * @param {number} zoom - Zoom level (1-18)
 * @param {number} width - Image width in pixels
 * @param {number} height - Image height in pixels
 * @returns {string} - Static map image URL
 */
export const getStaticMapUrl = (latitude, longitude, zoom = 15, width = 600, height = 400) => {
  // Using OpenStreetMap static map service
  return `https://staticmap.openstreetmap.de/staticmap.php?center=${latitude},${longitude}&zoom=${zoom}&size=${width}x${height}&markers=${latitude},${longitude},red`;
};

// Export all geolocation functions
const geolocationService = {
  getCurrentPosition,
  watchPosition,
  clearWatch,
  calculateDistance,
  getAddressFromCoordinates,
  getCoordinatesFromAddress,
  formatAddress,
  isGeolocationSupported,
  getStaticMapUrl,
};

export default geolocationService;