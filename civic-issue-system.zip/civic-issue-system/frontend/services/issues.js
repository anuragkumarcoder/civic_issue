/**
 * Issues service for handling issue-related API calls
 */

import api from './api';

/**
 * Get all issues with pagination and filters
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Issues response
 */
export const getIssues = async (params = {}) => {
  try {
    const response = await api.get('/issues', { params });
    return response;
  } catch (error) {
    console.error('Get issues error:', error);
    throw error;
  }
};

/**
 * Get a single issue by ID
 * @param {string} id - Issue ID
 * @returns {Promise<Object>} - Issue response
 */
export const getIssueById = async (id) => {
  try {
    const response = await api.get(`/issues/${id}`);
    return response;
  } catch (error) {
    console.error(`Get issue #${id} error:`, error);
    throw error;
  }
};

/**
 * Create a new issue
 * @param {Object} issueData - Issue data
 * @param {Array} images - Array of image files
 * @returns {Promise<Object>} - Create issue response
 */
export const createIssue = async (issueData, images = []) => {
  try {
    let response;
    
    if (images && images.length > 0) {
      const formData = new FormData();
      
      // Add issue data to form
      Object.keys(issueData).forEach(key => {
        if (issueData[key] !== undefined && issueData[key] !== null) {
          if (typeof issueData[key] === 'object' && !(issueData[key] instanceof File)) {
            formData.append(key, JSON.stringify(issueData[key]));
          } else {
            formData.append(key, issueData[key]);
          }
        }
      });
      
      // Add images to form
      images.forEach((image, index) => {
        formData.append(`image${index}`, image);
      });
      
      response = await api.postFormData('/issues', formData);
    } else {
      response = await api.post('/issues', issueData);
    }
    
    return response;
  } catch (error) {
    console.error('Create issue error:', error);
    throw error;
  }
};

/**
 * Update an existing issue
 * @param {string} id - Issue ID
 * @param {Object} issueData - Updated issue data
 * @param {Array} images - Array of image files
 * @returns {Promise<Object>} - Update issue response
 */
export const updateIssue = async (id, issueData, images = []) => {
  try {
    let response;
    
    if (images && images.length > 0) {
      const formData = new FormData();
      
      // Add issue data to form
      Object.keys(issueData).forEach(key => {
        if (issueData[key] !== undefined && issueData[key] !== null) {
          if (typeof issueData[key] === 'object' && !(issueData[key] instanceof File)) {
            formData.append(key, JSON.stringify(issueData[key]));
          } else {
            formData.append(key, issueData[key]);
          }
        }
      });
      
      // Add images to form
      images.forEach((image, index) => {
        formData.append(`image${index}`, image);
      });
      
      response = await api.putFormData(`/issues/${id}`, formData);
    } else {
      response = await api.put(`/issues/${id}`, issueData);
    }
    
    return response;
  } catch (error) {
    console.error(`Update issue #${id} error:`, error);
    throw error;
  }
};

/**
 * Delete an issue
 * @param {string} id - Issue ID
 * @returns {Promise<Object>} - Delete issue response
 */
export const deleteIssue = async (id) => {
  try {
    const response = await api.delete(`/issues/${id}`);
    return response;
  } catch (error) {
    console.error(`Delete issue #${id} error:`, error);
    throw error;
  }
};

/**
 * Vote on an issue
 * @param {string} id - Issue ID
 * @param {string} type - Vote type ('upvote' or 'downvote')
 * @returns {Promise<Object>} - Vote response
 */
export const voteIssue = async (id, type = 'upvote') => {
  try {
    const response = await api.post(`/issues/${id}/vote`, { type });
    return response;
  } catch (error) {
    console.error(`Vote on issue #${id} error:`, error);
    throw error;
  }
};

/**
 * Get issues reported by the current user
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - User issues response
 */
export const getMyIssues = async (params = {}) => {
  try {
    const response = await api.get('/issues/my-issues', { params });
    return response;
  } catch (error) {
    console.error('Get my issues error:', error);
    throw error;
  }
};

/**
 * Change the status of an issue
 * @param {string} id - Issue ID
 * @param {string} status - New status
 * @returns {Promise<Object>} - Status change response
 */
export const changeIssueStatus = async (id, status) => {
  try {
    const response = await api.put(`/issues/${id}/status`, { status });
    return response;
  } catch (error) {
    console.error(`Change issue #${id} status error:`, error);
    throw error;
  }
};

/**
 * Get issue statistics
 * @returns {Promise<Object>} - Issue statistics response
 */
export const getIssueStats = async () => {
  try {
    const response = await api.get('/issues/stats');
    return response;
  } catch (error) {
    console.error('Get issue statistics error:', error);
    throw error;
  }
};

/**
 * Get comments for an issue
 * @param {string} issueId - Issue ID
 * @returns {Promise<Object>} - Comments response
 */
export const getComments = async (issueId) => {
  try {
    const response = await api.get(`/issues/${issueId}/comments`);
    return response;
  } catch (error) {
    console.error(`Get comments for issue #${issueId} error:`, error);
    throw error;
  }
};

/**
 * Add a comment to an issue
 * @param {string} issueId - Issue ID
 * @param {Object} commentData - Comment data
 * @returns {Promise<Object>} - Add comment response
 */
export const addComment = async (issueId, commentData) => {
  try {
    const response = await api.post(`/issues/${issueId}/comments`, commentData);
    return response;
  } catch (error) {
    console.error(`Add comment to issue #${issueId} error:`, error);
    throw error;
  }
};

/**
 * Update a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @param {Object} commentData - Updated comment data
 * @returns {Promise<Object>} - Update comment response
 */
export const updateComment = async (issueId, commentId, commentData) => {
  try {
    const response = await api.put(`/issues/${issueId}/comments/${commentId}`, commentData);
    return response;
  } catch (error) {
    console.error(`Update comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Delete a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @returns {Promise<Object>} - Delete comment response
 */
export const deleteComment = async (issueId, commentId) => {
  try {
    const response = await api.delete(`/issues/${issueId}/comments/${commentId}`);
    return response;
  } catch (error) {
    console.error(`Delete comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Search issues
 * @param {string} query - Search query
 * @param {Object} params - Additional query parameters
 * @returns {Promise<Object>} - Search response
 */
export const searchIssues = async (query, params = {}) => {
  try {
    const searchParams = { ...params, search: query };
    const response = await api.get('/issues', { params: searchParams });
    return response;
  } catch (error) {
    console.error('Search issues error:', error);
    throw error;
  }
};

/**
 * Get nearby issues based on location
 * @param {number} latitude - Latitude coordinate
 * @param {number} longitude - Longitude coordinate
 * @param {number} radius - Search radius in kilometers
 * @param {Object} params - Additional query parameters
 * @returns {Promise<Object>} - Nearby issues response
 */
export const getNearbyIssues = async (latitude, longitude, radius = 5, params = {}) => {
  try {
    const locationParams = {
      ...params,
      latitude,
      longitude,
      radius,
    };
    
    const response = await api.get('/issues/nearby', { params: locationParams });
    return response;
  } catch (error) {
    console.error('Get nearby issues error:', error);
    throw error;
  }
};

// Export all issue-related functions
const issueService = {
  getIssues,
  getIssueById,
  createIssue,
  updateIssue,
  deleteIssue,
  voteIssue,
  getMyIssues,
  changeIssueStatus,
  getIssueStats,
  getComments,
  addComment,
  updateComment,
  deleteComment,
  searchIssues,
  getNearbyIssues,
};

export default issueService;