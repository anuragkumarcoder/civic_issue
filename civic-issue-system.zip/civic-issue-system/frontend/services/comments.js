/**
 * Comments service for handling comment-related API calls
 */

import api from './api';

/**
 * Get comments for an issue
 * @param {string} issueId - Issue ID
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Comments response
 */
export const getComments = async (issueId, params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/issues/${issueId}/comments?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error(`Get comments for issue #${issueId} error:`, error);
    throw error;
  }
};

/**
 * Get a specific comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @returns {Promise<Object>} - Comment response
 */
export const getComment = async (issueId, commentId) => {
  try {
    const response = await api.get(`/issues/${issueId}/comments/${commentId}`);
    return response;
  } catch (error) {
    console.error(`Get comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Create a new comment
 * @param {string} issueId - Issue ID
 * @param {Object} commentData - Comment data
 * @returns {Promise<Object>} - Create comment response
 */
export const createComment = async (issueId, commentData) => {
  try {
    const response = await api.post(`/issues/${issueId}/comments`, commentData);
    return response;
  } catch (error) {
    console.error(`Create comment for issue #${issueId} error:`, error);
    throw error;
  }
};

/**
 * Update a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @param {Object} commentData - Updated comment data
 * @returns {Promise<Object>} - Update comment response
 */
export const updateComment = async (issueId, commentId, commentData) => {
  try {
    const response = await api.put(`/issues/${issueId}/comments/${commentId}`, commentData);
    return response;
  } catch (error) {
    console.error(`Update comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Delete a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @returns {Promise<Object>} - Delete comment response
 */
export const deleteComment = async (issueId, commentId) => {
  try {
    const response = await api.delete(`/issues/${issueId}/comments/${commentId}`);
    return response;
  } catch (error) {
    console.error(`Delete comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Like a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @returns {Promise<Object>} - Like comment response
 */
export const likeComment = async (issueId, commentId) => {
  try {
    const response = await api.post(`/issues/${issueId}/comments/${commentId}/like`);
    return response;
  } catch (error) {
    console.error(`Like comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Unlike a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @returns {Promise<Object>} - Unlike comment response
 */
export const unlikeComment = async (issueId, commentId) => {
  try {
    const response = await api.delete(`/issues/${issueId}/comments/${commentId}/like`);
    return response;
  } catch (error) {
    console.error(`Unlike comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Report a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @param {Object} reportData - Report data
 * @returns {Promise<Object>} - Report comment response
 */
export const reportComment = async (issueId, commentId, reportData) => {
  try {
    const response = await api.post(`/issues/${issueId}/comments/${commentId}/report`, reportData);
    return response;
  } catch (error) {
    console.error(`Report comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Get replies to a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Replies response
 */
export const getReplies = async (issueId, commentId, params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/issues/${issueId}/comments/${commentId}/replies?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error(`Get replies for comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Create a reply to a comment
 * @param {string} issueId - Issue ID
 * @param {string} commentId - Comment ID
 * @param {Object} replyData - Reply data
 * @returns {Promise<Object>} - Create reply response
 */
export const createReply = async (issueId, commentId, replyData) => {
  try {
    const response = await api.post(`/issues/${issueId}/comments/${commentId}/replies`, replyData);
    return response;
  } catch (error) {
    console.error(`Create reply for comment #${commentId} error:`, error);
    throw error;
  }
};

/**
 * Get user's comment history
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Comment history response
 */
export const getUserCommentHistory = async (params = {}) => {
  try {
    const {
      page = 1,
      limit = 10,
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    
    const response = await api.get(`/users/me/comments?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error('Get user comment history error:', error);
    throw error;
  }
};

/**
 * Upload an image for a comment
 * @param {string} issueId - Issue ID
 * @param {File} imageFile - Image file
 * @returns {Promise<Object>} - Upload image response
 */
export const uploadCommentImage = async (issueId, imageFile) => {
  try {
    const formData = new FormData();
    formData.append('image', imageFile);
    
    const response = await api.postFormData(`/issues/${issueId}/comments/images`, formData);
    return response;
  } catch (error) {
    console.error(`Upload comment image for issue #${issueId} error:`, error);
    throw error;
  }
};

// Export all comment-related functions
const commentService = {
  getComments,
  getComment,
  createComment,
  updateComment,
  deleteComment,
  likeComment,
  unlikeComment,
  reportComment,
  getReplies,
  createReply,
  getUserCommentHistory,
  uploadCommentImage,
};

export default commentService;