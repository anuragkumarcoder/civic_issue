/**
 * Admin service for handling admin-related API calls
 */

import api from './api';

/**
 * Get all users with pagination
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Users response
 */
export const getUsers = async (params = {}) => {
  try {
    const response = await api.get('/admin/users', { params });
    return response;
  } catch (error) {
    console.error('Get users error:', error);
    throw error;
  }
};

/**
 * Get a single user by ID
 * @param {string} id - User ID
 * @returns {Promise<Object>} - User response
 */
export const getUserById = async (id) => {
  try {
    const response = await api.get(`/admin/users/${id}`);
    return response;
  } catch (error) {
    console.error(`Get user #${id} error:`, error);
    throw error;
  }
};

/**
 * Update a user
 * @param {string} id - User ID
 * @param {Object} userData - Updated user data
 * @returns {Promise<Object>} - Update user response
 */
export const updateUser = async (id, userData) => {
  try {
    const response = await api.put(`/admin/users/${id}`, userData);
    return response;
  } catch (error) {
    console.error(`Update user #${id} error:`, error);
    throw error;
  }
};

/**
 * Delete a user
 * @param {string} id - User ID
 * @returns {Promise<Object>} - Delete user response
 */
export const deleteUser = async (id) => {
  try {
    const response = await api.delete(`/admin/users/${id}`);
    return response;
  } catch (error) {
    console.error(`Delete user #${id} error:`, error);
    throw error;
  }
};

/**
 * Get system statistics
 * @returns {Promise<Object>} - System statistics response
 */
export const getSystemStats = async () => {
  try {
    const response = await api.get('/admin/stats');
    return response;
  } catch (error) {
    console.error('Get system statistics error:', error);
    throw error;
  }
};

/**
 * Get system logs
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - System logs response
 */
export const getSystemLogs = async (params = {}) => {
  try {
    const response = await api.get('/admin/logs', { params });
    return response;
  } catch (error) {
    console.error('Get system logs error:', error);
    throw error;
  }
};

/**
 * Update system settings
 * @param {Object} settings - System settings
 * @returns {Promise<Object>} - Update settings response
 */
export const updateSystemSettings = async (settings) => {
  try {
    const response = await api.put('/admin/settings', settings);
    return response;
  } catch (error) {
    console.error('Update system settings error:', error);
    throw error;
  }
};

/**
 * Get system settings
 * @returns {Promise<Object>} - System settings response
 */
export const getSystemSettings = async () => {
  try {
    const response = await api.get('/admin/settings');
    return response;
  } catch (error) {
    console.error('Get system settings error:', error);
    throw error;
  }
};

/**
 * Change a user's role
 * @param {string} userId - User ID
 * @param {string} role - New role
 * @returns {Promise<Object>} - Change role response
 */
export const changeUserRole = async (userId, role) => {
  try {
    const response = await api.put(`/admin/users/${userId}/role`, { role });
    return response;
  } catch (error) {
    console.error(`Change user #${userId} role error:`, error);
    throw error;
  }
};

/**
 * Ban a user
 * @param {string} userId - User ID
 * @param {Object} banData - Ban data (reason, duration)
 * @returns {Promise<Object>} - Ban user response
 */
export const banUser = async (userId, banData) => {
  try {
    const response = await api.put(`/admin/users/${userId}/ban`, banData);
    return response;
  } catch (error) {
    console.error(`Ban user #${userId} error:`, error);
    throw error;
  }
};

/**
 * Unban a user
 * @param {string} userId - User ID
 * @returns {Promise<Object>} - Unban user response
 */
export const unbanUser = async (userId) => {
  try {
    const response = await api.put(`/admin/users/${userId}/unban`);
    return response;
  } catch (error) {
    console.error(`Unban user #${userId} error:`, error);
    throw error;
  }
};

/**
 * Get all categories
 * @returns {Promise<Object>} - Categories response
 */
export const getCategories = async () => {
  try {
    const response = await api.get('/admin/categories');
    return response;
  } catch (error) {
    console.error('Get categories error:', error);
    throw error;
  }
};

/**
 * Create a new category
 * @param {Object} categoryData - Category data
 * @returns {Promise<Object>} - Create category response
 */
export const createCategory = async (categoryData) => {
  try {
    const response = await api.post('/admin/categories', categoryData);
    return response;
  } catch (error) {
    console.error('Create category error:', error);
    throw error;
  }
};

/**
 * Update a category
 * @param {string} categoryId - Category ID
 * @param {Object} categoryData - Updated category data
 * @returns {Promise<Object>} - Update category response
 */
export const updateCategory = async (categoryId, categoryData) => {
  try {
    const response = await api.put(`/admin/categories/${categoryId}`, categoryData);
    return response;
  } catch (error) {
    console.error(`Update category #${categoryId} error:`, error);
    throw error;
  }
};

/**
 * Delete a category
 * @param {string} categoryId - Category ID
 * @returns {Promise<Object>} - Delete category response
 */
export const deleteCategory = async (categoryId) => {
  try {
    const response = await api.delete(`/admin/categories/${categoryId}`);
    return response;
  } catch (error) {
    console.error(`Delete category #${categoryId} error:`, error);
    throw error;
  }
};

// Export all admin-related functions
const adminService = {
  getUsers,
  getUserById,
  updateUser,
  deleteUser,
  getSystemStats,
  getSystemLogs,
  updateSystemSettings,
  getSystemSettings,
  changeUserRole,
  banUser,
  unbanUser,
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
};

export default adminService;