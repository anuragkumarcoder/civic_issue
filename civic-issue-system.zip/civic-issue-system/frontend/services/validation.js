/**
 * Validation service for form inputs and data validation
 */

/**
 * Validate email address
 * @param {string} email - Email address to validate
 * @returns {boolean} - Whether email is valid
 */
export const validateEmail = (email) => {
  if (!email) return false;
  
  // RFC 5322 compliant email regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(email);
};

/**
 * Validate password strength
 * @param {string} password - Password to validate
 * @param {Object} options - Validation options
 * @returns {Object} - Validation result with isValid and errors
 */
export const validatePassword = (password, options = {}) => {
  const {
    minLength = 8,
    requireUppercase = true,
    requireLowercase = true,
    requireNumbers = true,
    requireSpecialChars = true,
  } = options;
  
  const errors = [];
  
  if (!password) {
    errors.push('Password is required');
    return { isValid: false, errors };
  }
  
  if (password.length < minLength) {
    errors.push(`Password must be at least ${minLength} characters long`);
  }
  
  if (requireUppercase && !/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  
  if (requireLowercase && !/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  
  if (requireNumbers && !/\d/.test(password)) {
    errors.push('Password must contain at least one number');
  }
  
  if (requireSpecialChars && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }
  
  return {
    isValid: errors.length === 0,
    errors,
  };
};

/**
 * Validate phone number
 * @param {string} phone - Phone number to validate
 * @param {string} countryCode - Country code for validation
 * @returns {boolean} - Whether phone number is valid
 */
export const validatePhone = (phone, countryCode = 'US') => {
  if (!phone) return false;
  
  // Basic international phone number validation
  // For production, consider using a library like libphonenumber-js
  const phoneRegex = /^\+?[\d\s()-]{7,20}$/;
  
  if (countryCode === 'US') {
    // US-specific validation (10 digits, optional country code)
    const usPhoneRegex = /^(\+?1)?[\s-]?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/;
    return usPhoneRegex.test(phone);
  }
  
  return phoneRegex.test(phone);
};

/**
 * Validate URL
 * @param {string} url - URL to validate
 * @param {boolean} requireHttps - Whether HTTPS is required
 * @returns {boolean} - Whether URL is valid
 */
export const validateUrl = (url, requireHttps = false) => {
  if (!url) return false;
  
  try {
    const urlObj = new URL(url);
    if (requireHttps && urlObj.protocol !== 'https:') {
      return false;
    }
    return true;
  } catch (e) {
    return false;
  }
};

/**
 * Validate date format
 * @param {string} date - Date string to validate
 * @param {string} format - Expected format (ISO, YMD, MDY, DMY)
 * @returns {boolean} - Whether date is valid
 */
export const validateDate = (date, format = 'ISO') => {
  if (!date) return false;
  
  // For ISO format (YYYY-MM-DD)
  if (format === 'ISO') {
    const isoRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!isoRegex.test(date)) return false;
  }
  
  // For YMD format (YYYY/MM/DD)
  if (format === 'YMD') {
    const ymdRegex = /^\d{4}\/\d{2}\/\d{2}$/;
    if (!ymdRegex.test(date)) return false;
  }
  
  // For MDY format (MM/DD/YYYY)
  if (format === 'MDY') {
    const mdyRegex = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!mdyRegex.test(date)) return false;
  }
  
  // For DMY format (DD/MM/YYYY)
  if (format === 'DMY') {
    const dmyRegex = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!dmyRegex.test(date)) return false;
  }
  
  // Check if it's a valid date
  const d = new Date(date);
  return !isNaN(d.getTime());
};

/**
 * Validate file type
 * @param {File} file - File to validate
 * @param {Array} allowedTypes - Array of allowed MIME types
 * @returns {boolean} - Whether file type is valid
 */
export const validateFileType = (file, allowedTypes = []) => {
  if (!file || !file.type) return false;
  if (allowedTypes.length === 0) return true;
  
  return allowedTypes.includes(file.type);
};

/**
 * Validate file size
 * @param {File} file - File to validate
 * @param {number} maxSizeInBytes - Maximum file size in bytes
 * @returns {boolean} - Whether file size is valid
 */
export const validateFileSize = (file, maxSizeInBytes) => {
  if (!file || typeof file.size !== 'number') return false;
  if (!maxSizeInBytes) return true;
  
  return file.size <= maxSizeInBytes;
};

/**
 * Validate image dimensions
 * @param {File} imageFile - Image file to validate
 * @param {Object} dimensions - Dimension constraints
 * @returns {Promise<Object>} - Validation result
 */
export const validateImageDimensions = (imageFile, dimensions = {}) => {
  return new Promise((resolve) => {
    if (!imageFile || !imageFile.type.startsWith('image/')) {
      resolve({ isValid: false, error: 'Not an image file' });
      return;
    }
    
    const img = new Image();
    const objectUrl = URL.createObjectURL(imageFile);
    
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      
      const { minWidth, maxWidth, minHeight, maxHeight, exactWidth, exactHeight } = dimensions;
      const errors = [];
      
      if (minWidth && img.width < minWidth) {
        errors.push(`Image width must be at least ${minWidth}px`);
      }
      
      if (maxWidth && img.width > maxWidth) {
        errors.push(`Image width must not exceed ${maxWidth}px`);
      }
      
      if (minHeight && img.height < minHeight) {
        errors.push(`Image height must be at least ${minHeight}px`);
      }
      
      if (maxHeight && img.height > maxHeight) {
        errors.push(`Image height must not exceed ${maxHeight}px`);
      }
      
      if (exactWidth && img.width !== exactWidth) {
        errors.push(`Image width must be exactly ${exactWidth}px`);
      }
      
      if (exactHeight && img.height !== exactHeight) {
        errors.push(`Image height must be exactly ${exactHeight}px`);
      }
      
      resolve({
        isValid: errors.length === 0,
        errors,
        dimensions: { width: img.width, height: img.height },
      });
    };
    
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      resolve({ isValid: false, error: 'Failed to load image' });
    };
    
    img.src = objectUrl;
  });
};

/**
 * Validate required fields in an object
 * @param {Object} data - Data object to validate
 * @param {Array} requiredFields - Array of required field names
 * @returns {Object} - Validation result with missing fields
 */
export const validateRequired = (data, requiredFields = []) => {
  if (!data || typeof data !== 'object') {
    return { isValid: false, missingFields: requiredFields };
  }
  
  const missingFields = requiredFields.filter(field => {
    const value = data[field];
    return value === undefined || value === null || value === '';
  });
  
  return {
    isValid: missingFields.length === 0,
    missingFields,
  };
};

/**
 * Validate text length
 * @param {string} text - Text to validate
 * @param {Object} options - Length constraints
 * @returns {Object} - Validation result
 */
export const validateTextLength = (text, options = {}) => {
  const { min = 0, max = Infinity } = options;
  
  if (text === undefined || text === null) {
    return { isValid: false, error: 'Text is required' };
  }
  
  const length = String(text).length;
  
  if (length < min) {
    return { isValid: false, error: `Text must be at least ${min} characters` };
  }
  
  if (length > max) {
    return { isValid: false, error: `Text must not exceed ${max} characters` };
  }
  
  return { isValid: true };
};

/**
 * Validate numeric value
 * @param {number|string} value - Value to validate
 * @param {Object} options - Numeric constraints
 * @returns {Object} - Validation result
 */
export const validateNumeric = (value, options = {}) => {
  const { min, max, integer = false } = options;
  
  if (value === undefined || value === null || value === '') {
    return { isValid: false, error: 'Value is required' };
  }
  
  const numValue = Number(value);
  
  if (isNaN(numValue)) {
    return { isValid: false, error: 'Value must be a number' };
  }
  
  if (integer && !Number.isInteger(numValue)) {
    return { isValid: false, error: 'Value must be an integer' };
  }
  
  if (min !== undefined && numValue < min) {
    return { isValid: false, error: `Value must be at least ${min}` };
  }
  
  if (max !== undefined && numValue > max) {
    return { isValid: false, error: `Value must not exceed ${max}` };
  }
  
  return { isValid: true };
};

/**
 * Validate postal/zip code
 * @param {string} code - Postal code to validate
 * @param {string} countryCode - Country code for validation
 * @returns {boolean} - Whether postal code is valid
 */
export const validatePostalCode = (code, countryCode = 'US') => {
  if (!code) return false;
  
  // Country-specific postal code validation
  const postalRegexes = {
    US: /^\d{5}(-\d{4})?$/, // US ZIP code (5 digits, optional 4-digit extension)
    CA: /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/, // Canadian postal code
    UK: /^[A-Za-z]{1,2}\d[A-Za-z\d]?[ ]?\d[A-Za-z]{2}$/, // UK postcode
    // Add more countries as needed
  };
  
  const regex = postalRegexes[countryCode] || /^[\w\d\s-]{3,10}$/; // Default regex
  return regex.test(code);
};

/**
 * Validate form data against a schema
 * @param {Object} data - Form data to validate
 * @param {Object} schema - Validation schema
 * @returns {Object} - Validation result with errors
 */
export const validateForm = (data, schema) => {
  if (!data || !schema) {
    return { isValid: false, errors: { _form: ['Invalid data or schema'] } };
  }
  
  const errors = {};
  let isValid = true;
  
  Object.keys(schema).forEach(field => {
    const fieldSchema = schema[field];
    const value = data[field];
    const fieldErrors = [];
    
    // Required validation
    if (fieldSchema.required && (value === undefined || value === null || value === '')) {
      fieldErrors.push(`${fieldSchema.label || field} is required`);
    }
    
    // Skip further validation if value is empty and not required
    if ((value === undefined || value === null || value === '') && !fieldSchema.required) {
      return;
    }
    
    // Type validation
    if (fieldSchema.type) {
      switch (fieldSchema.type) {
        case 'email':
          if (!validateEmail(value)) {
            fieldErrors.push(`${fieldSchema.label || field} must be a valid email address`);
          }
          break;
          
        case 'url':
          if (!validateUrl(value, fieldSchema.requireHttps)) {
            fieldErrors.push(`${fieldSchema.label || field} must be a valid URL`);
          }
          break;
          
        case 'number':
          const numResult = validateNumeric(value, {
            min: fieldSchema.min,
            max: fieldSchema.max,
            integer: fieldSchema.integer,
          });
          
          if (!numResult.isValid) {
            fieldErrors.push(numResult.error);
          }
          break;
          
        case 'date':
          if (!validateDate(value, fieldSchema.format)) {
            fieldErrors.push(`${fieldSchema.label || field} must be a valid date`);
          }
          break;
          
        case 'phone':
          if (!validatePhone(value, fieldSchema.countryCode)) {
            fieldErrors.push(`${fieldSchema.label || field} must be a valid phone number`);
          }
          break;
          
        case 'postal':
          if (!validatePostalCode(value, fieldSchema.countryCode)) {
            fieldErrors.push(`${fieldSchema.label || field} must be a valid postal code`);
          }
          break;
      }
    }
    
    // Length validation
    if (fieldSchema.minLength !== undefined || fieldSchema.maxLength !== undefined) {
      const lengthResult = validateTextLength(value, {
        min: fieldSchema.minLength,
        max: fieldSchema.maxLength,
      });
      
      if (!lengthResult.isValid) {
        fieldErrors.push(lengthResult.error);
      }
    }
    
    // Custom validation
    if (fieldSchema.validate && typeof fieldSchema.validate === 'function') {
      const customResult = fieldSchema.validate(value, data);
      
      if (customResult !== true) {
        fieldErrors.push(customResult);
      }
    }
    
    // Add field errors if any
    if (fieldErrors.length > 0) {
      errors[field] = fieldErrors;
      isValid = false;
    }
  });
  
  return { isValid, errors };
};

// Export all validation functions
const validationService = {
  validateEmail,
  validatePassword,
  validatePhone,
  validateUrl,
  validateDate,
  validateFileType,
  validateFileSize,
  validateImageDimensions,
  validateRequired,
  validateTextLength,
  validateNumeric,
  validatePostalCode,
  validateForm,
};

export default validationService;