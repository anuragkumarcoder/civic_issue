/**
 * Image service for handling image processing and uploads
 */

import api from './api';

/**
 * Compress an image file
 * @param {File} file - Image file to compress
 * @param {Object} options - Compression options
 * @returns {Promise<File>} - Compressed image file
 */
export const compressImage = async (file, options = {}) => {
  const {
    maxWidth = 1920,
    maxHeight = 1080,
    quality = 0.8,
    format = 'jpeg',
  } = options;
  
  return new Promise((resolve, reject) => {
    // Check if file is an image
    if (!file || !file.type.startsWith('image/')) {
      reject(new Error('Not an image file'));
      return;
    }
    
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const img = new Image();
      
      img.onload = () => {
        // Calculate new dimensions while maintaining aspect ratio
        let width = img.width;
        let height = img.height;
        
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
        
        if (height > maxHeight) {
          width = (width * maxHeight) / height;
          height = maxHeight;
        }
        
        // Create canvas for resizing
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        
        // Draw image on canvas
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        // Convert to blob
        const mimeType = format === 'jpeg' ? 'image/jpeg' : 'image/png';
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Failed to compress image'));
              return;
            }
            
            // Create new file from blob
            const compressedFile = new File(
              [blob],
              file.name,
              { type: mimeType }
            );
            
            resolve(compressedFile);
          },
          mimeType,
          quality
        );
      };
      
      img.onerror = () => {
        reject(new Error('Failed to load image'));
      };
      
      img.src = event.target.result;
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsDataURL(file);
  });
};

/**
 * Resize an image file
 * @param {File} file - Image file to resize
 * @param {number} width - Target width
 * @param {number} height - Target height
 * @param {boolean} maintainAspectRatio - Whether to maintain aspect ratio
 * @returns {Promise<File>} - Resized image file
 */
export const resizeImage = async (file, width, height, maintainAspectRatio = true) => {
  return new Promise((resolve, reject) => {
    // Check if file is an image
    if (!file || !file.type.startsWith('image/')) {
      reject(new Error('Not an image file'));
      return;
    }
    
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const img = new Image();
      
      img.onload = () => {
        let targetWidth = width;
        let targetHeight = height;
        
        // Maintain aspect ratio if required
        if (maintainAspectRatio) {
          const aspectRatio = img.width / img.height;
          
          if (width / height > aspectRatio) {
            targetWidth = targetHeight * aspectRatio;
          } else {
            targetHeight = targetWidth / aspectRatio;
          }
        }
        
        // Create canvas for resizing
        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        
        // Draw image on canvas
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, targetWidth, targetHeight);
        
        // Convert to blob
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Failed to resize image'));
              return;
            }
            
            // Create new file from blob
            const resizedFile = new File(
              [blob],
              file.name,
              { type: file.type }
            );
            
            resolve(resizedFile);
          },
          file.type
        );
      };
      
      img.onerror = () => {
        reject(new Error('Failed to load image'));
      };
      
      img.src = event.target.result;
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsDataURL(file);
  });
};

/**
 * Crop an image file
 * @param {File} file - Image file to crop
 * @param {Object} cropArea - Crop area coordinates
 * @returns {Promise<File>} - Cropped image file
 */
export const cropImage = async (file, cropArea) => {
  const { x, y, width, height } = cropArea;
  
  return new Promise((resolve, reject) => {
    // Check if file is an image
    if (!file || !file.type.startsWith('image/')) {
      reject(new Error('Not an image file'));
      return;
    }
    
    const reader = new FileReader();
    
    reader.onload = (event) => {
      const img = new Image();
      
      img.onload = () => {
        // Create canvas for cropping
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        
        // Draw cropped image on canvas
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, x, y, width, height, 0, 0, width, height);
        
        // Convert to blob
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Failed to crop image'));
              return;
            }
            
            // Create new file from blob
            const croppedFile = new File(
              [blob],
              file.name,
              { type: file.type }
            );
            
            resolve(croppedFile);
          },
          file.type
        );
      };
      
      img.onerror = () => {
        reject(new Error('Failed to load image'));
      };
      
      img.src = event.target.result;
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsDataURL(file);
  });
};

/**
 * Convert image to base64 string
 * @param {File} file - Image file to convert
 * @returns {Promise<string>} - Base64 string
 */
export const imageToBase64 = async (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = () => {
      resolve(reader.result);
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to convert image to base64'));
    };
    
    reader.readAsDataURL(file);
  });
};

/**
 * Convert base64 string to file
 * @param {string} base64 - Base64 string
 * @param {string} filename - Output filename
 * @param {string} mimeType - MIME type
 * @returns {File} - File object
 */
export const base64ToFile = (base64, filename, mimeType = 'image/jpeg') => {
  const arr = base64.split(',');
  const matchedMime = arr[0].match(/:(.*?);/)?.[1];
  const mime = mimeType || matchedMime || 'image/jpeg';
  const bstr = atob(arr[1]);
  let n = bstr.length;
  const u8arr = new Uint8Array(n);
  
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  
  return new File([u8arr], filename, { type: mime });
};

/**
 * Get image dimensions
 * @param {File} file - Image file
 * @returns {Promise<Object>} - Image dimensions
 */
export const getImageDimensions = async (file) => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);
    
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      resolve({
        width: img.width,
        height: img.height,
        aspectRatio: img.width / img.height,
      });
    };
    
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Failed to load image'));
    };
    
    img.src = objectUrl;
  });
};

/**
 * Upload an image to the server
 * @param {File} file - Image file to upload
 * @param {string} endpoint - API endpoint
 * @param {Object} additionalData - Additional form data
 * @returns {Promise<Object>} - Upload response
 */
export const uploadImage = async (file, endpoint = '/uploads/images', additionalData = {}) => {
  try {
    const formData = new FormData();
    formData.append('image', file);
    
    // Add additional data to form data
    Object.entries(additionalData).forEach(([key, value]) => {
      formData.append(key, value);
    });
    
    const response = await api.postFormData(endpoint, formData);
    return response;
  } catch (error) {
    console.error('Image upload error:', error);
    throw error;
  }
};

/**
 * Upload multiple images to the server
 * @param {Array<File>} files - Image files to upload
 * @param {string} endpoint - API endpoint
 * @param {Object} additionalData - Additional form data
 * @returns {Promise<Array<Object>>} - Upload responses
 */
export const uploadMultipleImages = async (files, endpoint = '/uploads/images', additionalData = {}) => {
  try {
    const formData = new FormData();
    
    // Append each file to form data
    files.forEach((file, index) => {
      formData.append(`images[${index}]`, file);
    });
    
    // Add additional data to form data
    Object.entries(additionalData).forEach(([key, value]) => {
      formData.append(key, value);
    });
    
    const response = await api.postFormData(endpoint, formData);
    return response;
  } catch (error) {
    console.error('Multiple image upload error:', error);
    throw error;
  }
};

/**
 * Process and upload an image
 * @param {File} file - Image file to process and upload
 * @param {Object} options - Processing options
 * @returns {Promise<Object>} - Upload response
 */
export const processAndUploadImage = async (file, options = {}) => {
  try {
    const {
      compress = true,
      resize = false,
      crop = false,
      width,
      height,
      cropArea,
      endpoint = '/uploads/images',
      additionalData = {},
    } = options;
    
    let processedFile = file;
    
    // Apply image processing in sequence
    if (compress) {
      processedFile = await compressImage(processedFile, options);
    }
    
    if (resize && width && height) {
      processedFile = await resizeImage(processedFile, width, height, options.maintainAspectRatio);
    }
    
    if (crop && cropArea) {
      processedFile = await cropImage(processedFile, cropArea);
    }
    
    // Upload processed image
    return await uploadImage(processedFile, endpoint, additionalData);
  } catch (error) {
    console.error('Process and upload image error:', error);
    throw error;
  }
};

/**
 * Get image file from URL
 * @param {string} url - Image URL
 * @param {string} filename - Output filename
 * @returns {Promise<File>} - Image file
 */
export const getImageFileFromUrl = async (url, filename) => {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    return new File([blob], filename || 'image.jpg', { type: blob.type });
  } catch (error) {
    console.error('Error getting image from URL:', error);
    throw error;
  }
};

// Export all image service functions
const imageService = {
  compressImage,
  resizeImage,
  cropImage,
  imageToBase64,
  base64ToFile,
  getImageDimensions,
  uploadImage,
  uploadMultipleImages,
  processAndUploadImage,
  getImageFileFromUrl,
};

export default imageService;