/**
 * Authentication service for handling user authentication
 */

import api from './api';
import { storage } from './utils';

// Constants
const TOKEN_KEY = 'token';
const USER_KEY = 'user';

/**
 * Login a user
 * @param {Object} credentials - User credentials
 * @returns {Promise<Object>} - Login response
 */
export const login = async (credentials) => {
  try {
    const response = await api.post('/auth/login', credentials);
    
    if (response.success && response.token) {
      // Store token and user data
      storage.set(TOKEN_KEY, response.token);
      storage.set(USER_KEY, response.user);
    }
    
    return response;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

/**
 * Register a new user
 * @param {Object} userData - User registration data
 * @returns {Promise<Object>} - Registration response
 */
export const register = async (userData) => {
  try {
    const response = await api.post('/auth/register', userData);
    
    if (response.success && response.token) {
      // Store token and user data
      storage.set(TOKEN_KEY, response.token);
      storage.set(USER_KEY, response.user);
    }
    
    return response;
  } catch (error) {
    console.error('Registration error:', error);
    throw error;
  }
};

/**
 * Logout the current user
 * @returns {Promise<Object>} - Logout response
 */
export const logout = async () => {
  try {
    // Call logout endpoint
    await api.post('/auth/logout');
  } catch (error) {
    console.error('Logout error:', error);
  } finally {
    // Clear local storage regardless of API response
    storage.remove(TOKEN_KEY);
    storage.remove(USER_KEY);
  }
  
  return { success: true };
};

/**
 * Get the current authenticated user
 * @returns {Object|null} - User data or null if not authenticated
 */
export const getCurrentUser = () => {
  return storage.get(USER_KEY);
};

/**
 * Check if a user is authenticated
 * @returns {boolean} - Authentication status
 */
export const isAuthenticated = () => {
  const token = storage.get(TOKEN_KEY, false);
  return !!token;
};

/**
 * Get the authentication token
 * @returns {string|null} - Authentication token
 */
export const getToken = () => {
  return storage.get(TOKEN_KEY, false);
};

/**
 * Update the current user's profile
 * @param {Object} profileData - Profile data to update
 * @param {File} avatar - Avatar image file (optional)
 * @returns {Promise<Object>} - Update response
 */
export const updateProfile = async (profileData, avatar = null) => {
  try {
    let response;
    
    if (avatar) {
      const formData = new FormData();
      
      // Add profile data to form
      Object.keys(profileData).forEach(key => {
        formData.append(key, profileData[key]);
      });
      
      // Add avatar file
      formData.append('avatar', avatar);
      
      response = await api.postFormData('/auth/profile', formData);
    } else {
      response = await api.put('/auth/profile', profileData);
    }
    
    if (response.success && response.user) {
      // Update stored user data
      storage.set(USER_KEY, response.user);
    }
    
    return response;
  } catch (error) {
    console.error('Profile update error:', error);
    throw error;
  }
};

/**
 * Change the current user's password
 * @param {Object} passwordData - Password data
 * @returns {Promise<Object>} - Change password response
 */
export const changePassword = async (passwordData) => {
  try {
    const response = await api.put('/auth/change-password', passwordData);
    return response;
  } catch (error) {
    console.error('Password change error:', error);
    throw error;
  }
};

/**
 * Request a password reset
 * @param {string} email - User email
 * @returns {Promise<Object>} - Password reset request response
 */
export const forgotPassword = async (email) => {
  try {
    const response = await api.post('/auth/forgot-password', { email });
    return response;
  } catch (error) {
    console.error('Forgot password error:', error);
    throw error;
  }
};

/**
 * Reset a password with a token
 * @param {string} token - Reset token
 * @param {string} password - New password
 * @returns {Promise<Object>} - Password reset response
 */
export const resetPassword = async (token, password) => {
  try {
    const response = await api.post('/auth/reset-password', { token, password });
    return response;
  } catch (error) {
    console.error('Reset password error:', error);
    throw error;
  }
};

/**
 * Verify a user's email with a token
 * @param {string} token - Verification token
 * @returns {Promise<Object>} - Email verification response
 */
export const verifyEmail = async (token) => {
  try {
    const response = await api.get(`/auth/verify-email/${token}`);
    
    if (response.success && response.user) {
      // Update stored user data if available
      const currentUser = getCurrentUser();
      if (currentUser && currentUser.id === response.user.id) {
        storage.set(USER_KEY, response.user);
      }
    }
    
    return response;
  } catch (error) {
    console.error('Email verification error:', error);
    throw error;
  }
};

/**
 * Resend email verification
 * @param {string} email - User email
 * @returns {Promise<Object>} - Resend verification response
 */
export const resendVerification = async (email) => {
  try {
    const response = await api.post('/auth/resend-verification', { email });
    return response;
  } catch (error) {
    console.error('Resend verification error:', error);
    throw error;
  }
};

/**
 * Check if the current user has a specific role
 * @param {string} role - Role to check
 * @returns {boolean} - Whether user has the role
 */
export const hasRole = (role) => {
  const user = getCurrentUser();
  if (!user || !user.role) return false;
  
  return user.role === role;
};

/**
 * Check if the current user has admin privileges
 * @returns {boolean} - Whether user is an admin
 */
export const isAdmin = () => {
  return hasRole('ADMIN');
};

/**
 * Check if the current user has moderator privileges
 * @returns {boolean} - Whether user is a moderator
 */
export const isModerator = () => {
  return hasRole('MODERATOR') || hasRole('ADMIN');
};

/**
 * Refresh the authentication token
 * @returns {Promise<Object>} - Token refresh response
 */
export const refreshToken = async () => {
  try {
    const response = await api.post('/auth/refresh-token');
    
    if (response.success && response.token) {
      // Update stored token
      storage.set(TOKEN_KEY, response.token);
    }
    
    return response;
  } catch (error) {
    console.error('Token refresh error:', error);
    throw error;
  }
};

// Export all authentication functions
const authService = {
  login,
  register,
  logout,
  getCurrentUser,
  isAuthenticated,
  getToken,
  updateProfile,
  changePassword,
  forgotPassword,
  resetPassword,
  verifyEmail,
  resendVerification,
  hasRole,
  isAdmin,
  isModerator,
  refreshToken,
};

export default authService;