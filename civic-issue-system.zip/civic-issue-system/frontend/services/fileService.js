/**
 * File service for handling file uploads and downloads
 */

import api from './api';

/**
 * Upload a single file
 * @param {File} file - File to upload
 * @param {string} type - File type (avatar, issue, comment, etc.)
 * @param {Object} metadata - Additional metadata
 * @returns {Promise<Object>} - Upload response
 */
export const uploadFile = async (file, type = 'general', metadata = {}) => {
  try {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', type);
    
    // Add metadata as JSON string
    if (Object.keys(metadata).length > 0) {
      formData.append('metadata', JSON.stringify(metadata));
    }
    
    const response = await api.postFormData('/files/upload', formData);
    return response;
  } catch (error) {
    console.error('Upload file error:', error);
    throw error;
  }
};

/**
 * Upload multiple files
 * @param {Array<File>} files - Files to upload
 * @param {string} type - Files type (issue, comment, etc.)
 * @param {Object} metadata - Additional metadata
 * @returns {Promise<Object>} - Upload response
 */
export const uploadMultipleFiles = async (files, type = 'general', metadata = {}) => {
  try {
    const formData = new FormData();
    
    // Append each file
    files.forEach((file, index) => {
      formData.append(`files`, file);
    });
    
    formData.append('type', type);
    
    // Add metadata as JSON string
    if (Object.keys(metadata).length > 0) {
      formData.append('metadata', JSON.stringify(metadata));
    }
    
    const response = await api.postFormData('/files/upload-multiple', formData);
    return response;
  } catch (error) {
    console.error('Upload multiple files error:', error);
    throw error;
  }
};

/**
 * Download a file
 * @param {string} fileId - File ID
 * @returns {Promise<Blob>} - File blob
 */
export const downloadFile = async (fileId) => {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/files/${fileId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('accessToken')}`,
      },
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const blob = await response.blob();
    return blob;
  } catch (error) {
    console.error(`Download file #${fileId} error:`, error);
    throw error;
  }
};

/**
 * Get file metadata
 * @param {string} fileId - File ID
 * @returns {Promise<Object>} - File metadata response
 */
export const getFileMetadata = async (fileId) => {
  try {
    const response = await api.get(`/files/${fileId}/metadata`);
    return response;
  } catch (error) {
    console.error(`Get file #${fileId} metadata error:`, error);
    throw error;
  }
};

/**
 * Delete a file
 * @param {string} fileId - File ID
 * @returns {Promise<Object>} - Delete file response
 */
export const deleteFile = async (fileId) => {
  try {
    const response = await api.delete(`/files/${fileId}`);
    return response;
  } catch (error) {
    console.error(`Delete file #${fileId} error:`, error);
    throw error;
  }
};

/**
 * Get files by type
 * @param {string} type - File type (avatar, issue, comment, etc.)
 * @param {Object} params - Query parameters
 * @returns {Promise<Object>} - Files response
 */
export const getFilesByType = async (type, params = {}) => {
  try {
    const {
      page = 1,
      limit = 20,
      sortBy = 'createdAt',
      sortOrder = 'desc',
    } = params;
    
    // Build query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('type', type);
    queryParams.append('page', page.toString());
    queryParams.append('limit', limit.toString());
    queryParams.append('sortBy', sortBy);
    queryParams.append('sortOrder', sortOrder);
    
    const response = await api.get(`/files?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error(`Get files by type ${type} error:`, error);
    throw error;
  }
};

/**
 * Get files by parent ID (e.g., issue ID, comment ID)
 * @param {string} parentId - Parent ID
 * @param {string} parentType - Parent type (issue, comment, etc.)
 * @returns {Promise<Object>} - Files response
 */
export const getFilesByParent = async (parentId, parentType) => {
  try {
    const queryParams = new URLSearchParams();
    queryParams.append('parentId', parentId);
    queryParams.append('parentType', parentType);
    
    const response = await api.get(`/files/by-parent?${queryParams.toString()}`);
    return response;
  } catch (error) {
    console.error(`Get files by parent #${parentId} error:`, error);
    throw error;
  }
};

/**
 * Generate a presigned URL for direct file upload
 * @param {string} fileName - File name
 * @param {string} fileType - File MIME type
 * @param {string} type - File category (avatar, issue, comment, etc.)
 * @returns {Promise<Object>} - Presigned URL response
 */
export const getPresignedUploadUrl = async (fileName, fileType, type = 'general') => {
  try {
    const response = await api.post('/files/presigned-upload', {
      fileName,
      fileType,
      type,
    });
    return response;
  } catch (error) {
    console.error('Get presigned upload URL error:', error);
    throw error;
  }
};

/**
 * Upload to a presigned URL
 * @param {string} presignedUrl - Presigned URL
 * @param {File} file - File to upload
 * @returns {Promise<Object>} - Upload response
 */
export const uploadToPresignedUrl = async (presignedUrl, file) => {
  try {
    const response = await fetch(presignedUrl, {
      method: 'PUT',
      body: file,
      headers: {
        'Content-Type': file.type,
      },
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    return { success: true };
  } catch (error) {
    console.error('Upload to presigned URL error:', error);
    throw error;
  }
};

/**
 * Check if a file exists
 * @param {string} fileId - File ID
 * @returns {Promise<boolean>} - Whether file exists
 */
export const checkFileExists = async (fileId) => {
  try {
    const response = await api.head(`/files/${fileId}`);
    return response.status === 200;
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return false;
    }
    console.error(`Check file #${fileId} exists error:`, error);
    throw error;
  }
};

/**
 * Get file URL
 * @param {string} fileId - File ID
 * @returns {string} - File URL
 */
export const getFileUrl = (fileId) => {
  return `${process.env.NEXT_PUBLIC_API_URL}/files/${fileId}`;
};

/**
 * Get image thumbnail URL
 * @param {string} fileId - File ID
 * @param {Object} options - Thumbnail options
 * @returns {string} - Thumbnail URL
 */
export const getImageThumbnailUrl = (fileId, options = {}) => {
  const {
    width = 200,
    height = 200,
    fit = 'cover', // cover, contain, fill
  } = options;
  
  const queryParams = new URLSearchParams();
  queryParams.append('width', width.toString());
  queryParams.append('height', height.toString());
  queryParams.append('fit', fit);
  
  return `${process.env.NEXT_PUBLIC_API_URL}/files/${fileId}/thumbnail?${queryParams.toString()}`;
};

// Export all file-related functions
const fileService = {
  uploadFile,
  uploadMultipleFiles,
  downloadFile,
  getFileMetadata,
  deleteFile,
  getFilesByType,
  getFilesByParent,
  getPresignedUploadUrl,
  uploadToPresignedUrl,
  checkFileExists,
  getFileUrl,
  getImageThumbnailUrl,
};

export default fileService;