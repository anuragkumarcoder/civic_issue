/**
 * Permissions service for handling user permissions and access control
 */

import api from './api';

// Permission levels
const PERMISSION_LEVELS = {
  NONE: 0,
  READ: 1,
  COMMENT: 2,
  EDIT: 3,
  MODERATE: 4,
  ADMIN: 5,
};

// User roles
const USER_ROLES = {
  GUEST: 'guest',
  USER: 'user',
  MODERATOR: 'moderator',
  ADMIN: 'admin',
};

// Store current user permissions
let currentUserPermissions = null;

/**
 * Initialize permissions service
 * @returns {Promise<Object>} - Initialization result
 */
export const initialize = async () => {
  try {
    // Load current user permissions
    await loadCurrentUserPermissions();
    
    return { success: true };
  } catch (error) {
    console.error('Error initializing permissions service:', error);
    return { success: false, error };
  }
};

/**
 * Load current user permissions from API
 * @returns {Promise<Object>} - User permissions
 */
export const loadCurrentUserPermissions = async () => {
  try {
    // Check if user is authenticated
    const token = localStorage.getItem('token');
    
    if (!token) {
      // Set guest permissions
      currentUserPermissions = {
        role: USER_ROLES.GUEST,
        permissions: {},
      };
      
      return currentUserPermissions;
    }
    
    // Fetch user permissions from API
    const response = await api.get('/auth/permissions');
    currentUserPermissions = response.data;
    
    return currentUserPermissions;
  } catch (error) {
    console.error('Error loading user permissions:', error);
    
    // Set guest permissions on error
    currentUserPermissions = {
      role: USER_ROLES.GUEST,
      permissions: {},
    };
    
    return currentUserPermissions;
  }
};

/**
 * Get current user permissions
 * @returns {Object} - User permissions
 */
export const getCurrentUserPermissions = () => {
  return currentUserPermissions;
};

/**
 * Check if user has a specific permission
 * @param {string} permission - Permission to check
 * @param {number} level - Required permission level
 * @returns {boolean} - Whether user has permission
 */
export const hasPermission = (permission, level = PERMISSION_LEVELS.READ) => {
  if (!currentUserPermissions) {
    return false;
  }
  
  // Admin role has all permissions
  if (currentUserPermissions.role === USER_ROLES.ADMIN) {
    return true;
  }
  
  // Check specific permission
  const userPermissionLevel = currentUserPermissions.permissions[permission] || PERMISSION_LEVELS.NONE;
  
  return userPermissionLevel >= level;
};

/**
 * Check if user has a specific role
 * @param {string|Array<string>} roles - Role(s) to check
 * @returns {boolean} - Whether user has role
 */
export const hasRole = (roles) => {
  if (!currentUserPermissions) {
    return false;
  }
  
  const userRole = currentUserPermissions.role;
  
  // Check if user has any of the specified roles
  if (Array.isArray(roles)) {
    return roles.includes(userRole);
  }
  
  // Check single role
  return userRole === roles;
};

/**
 * Check if user is authenticated
 * @returns {boolean} - Whether user is authenticated
 */
export const isAuthenticated = () => {
  if (!currentUserPermissions) {
    return false;
  }
  
  return currentUserPermissions.role !== USER_ROLES.GUEST;
};

/**
 * Check if user can access a specific route
 * @param {Object} route - Route object with required permissions
 * @returns {boolean} - Whether user can access route
 */
export const canAccessRoute = (route) => {
  // Public routes are accessible to everyone
  if (!route.meta || !route.meta.requiresAuth) {
    return true;
  }
  
  // Check if user is authenticated
  if (!isAuthenticated()) {
    return false;
  }
  
  // Check required roles
  if (route.meta.roles && !hasRole(route.meta.roles)) {
    return false;
  }
  
  // Check required permissions
  if (route.meta.permissions) {
    for (const [permission, level] of Object.entries(route.meta.permissions)) {
      if (!hasPermission(permission, level)) {
        return false;
      }
    }
  }
  
  return true;
};

/**
 * Check if user can perform a specific action on an entity
 * @param {string} action - Action to perform (create, read, update, delete)
 * @param {string} entityType - Type of entity (issue, comment, user, etc.)
 * @param {Object} entity - Entity object
 * @returns {boolean} - Whether user can perform action
 */
export const canPerformAction = (action, entityType, entity = null) => {
  // Map actions to permission levels
  const actionLevels = {
    create: PERMISSION_LEVELS.EDIT,
    read: PERMISSION_LEVELS.READ,
    update: PERMISSION_LEVELS.EDIT,
    delete: PERMISSION_LEVELS.EDIT,
    moderate: PERMISSION_LEVELS.MODERATE,
  };
  
  // Get required permission level for action
  const requiredLevel = actionLevels[action] || PERMISSION_LEVELS.EDIT;
  
  // Check general permission for entity type
  const generalPermission = `${entityType}:${action}`;
  if (hasPermission(generalPermission, requiredLevel)) {
    return true;
  }
  
  // Check if user is the owner of the entity
  if (entity && entity.userId) {
    const currentUserId = currentUserPermissions?.userId;
    if (currentUserId && entity.userId === currentUserId) {
      // Check owner permission
      const ownerPermission = `${entityType}:${action}Own`;
      return hasPermission(ownerPermission, requiredLevel);
    }
  }
  
  return false;
};

/**
 * Get permissions for a specific entity
 * @param {string} entityType - Type of entity
 * @param {Object} entity - Entity object
 * @returns {Object} - Object with boolean flags for each action
 */
export const getEntityPermissions = (entityType, entity = null) => {
  return {
    canCreate: canPerformAction('create', entityType, entity),
    canRead: canPerformAction('read', entityType, entity),
    canUpdate: canPerformAction('update', entityType, entity),
    canDelete: canPerformAction('delete', entityType, entity),
    canModerate: canPerformAction('moderate', entityType, entity),
  };
};

/**
 * Get role display name
 * @param {string} role - Role code
 * @returns {string} - Role display name
 */
export const getRoleDisplayName = (role) => {
  const roleNames = {
    [USER_ROLES.GUEST]: 'Guest',
    [USER_ROLES.USER]: 'User',
    [USER_ROLES.MODERATOR]: 'Moderator',
    [USER_ROLES.ADMIN]: 'Administrator',
  };
  
  return roleNames[role] || role;
};

// Export constants and functions
export { PERMISSION_LEVELS, USER_ROLES };

// Export all permissions-related functions
const permissionsService = {
  initialize,
  loadCurrentUserPermissions,
  getCurrentUserPermissions,
  hasPermission,
  hasRole,
  isAuthenticated,
  canAccessRoute,
  canPerformAction,
  getEntityPermissions,
  getRoleDisplayName,
  PERMISSION_LEVELS,
  USER_ROLES,
};

export default permissionsService;