/**
 * Error reporting service for logging and reporting errors
 */

import analyticsService from './analytics';

// Default configuration
let config = {
  enabled: process.env.NODE_ENV === 'production',
  logToConsole: process.env.NODE_ENV === 'development',
  captureUnhandledErrors: true,
  captureUnhandledRejections: true,
  captureNetworkErrors: true,
  errorSamplingRate: 1.0, // 1.0 = 100% of errors are reported
  maxErrorsPerMinute: 10,
};

// Error count tracking
let errorCount = 0;
let lastErrorReset = Date.now();

/**
 * Initialize the error reporting service
 * @param {Object} options - Configuration options
 */
export const initErrorReporting = (options = {}) => {
  config = { ...config, ...options };
  
  if (!config.enabled) {
    console.log('Error reporting disabled');
    return;
  }
  
  // Set up global error handlers
  if (config.captureUnhandledErrors && typeof window !== 'undefined') {
    window.addEventListener('error', handleGlobalError);
  }
  
  if (config.captureUnhandledRejections && typeof window !== 'undefined') {
    window.addEventListener('unhandledrejection', handleUnhandledRejection);
  }
  
  console.log('Error reporting initialized');
};

/**
 * Handle global error event
 * @param {ErrorEvent} event - Error event
 */
const handleGlobalError = (event) => {
  const { message, filename, lineno, colno, error } = event;
  
  reportError({
    type: 'unhandled_error',
    message,
    source: filename,
    line: lineno,
    column: colno,
    stack: error?.stack,
    originalError: error,
  });
};

/**
 * Handle unhandled promise rejection
 * @param {PromiseRejectionEvent} event - Promise rejection event
 */
const handleUnhandledRejection = (event) => {
  const error = event.reason;
  
  reportError({
    type: 'unhandled_rejection',
    message: error?.message || 'Unhandled Promise Rejection',
    stack: error?.stack,
    originalError: error,
  });
};

/**
 * Report an error
 * @param {Object} errorData - Error data
 */
export const reportError = (errorData) => {
  // Check if error reporting is enabled
  if (!config.enabled) {
    if (config.logToConsole) {
      console.error('[Error Reporting]', errorData);
    }
    return;
  }
  
  // Apply error sampling rate
  if (Math.random() > config.errorSamplingRate) {
    return;
  }
  
  // Check rate limiting
  const now = Date.now();
  if (now - lastErrorReset > 60000) { // 1 minute
    errorCount = 0;
    lastErrorReset = now;
  }
  
  if (errorCount >= config.maxErrorsPerMinute) {
    return;
  }
  
  errorCount++;
  
  // Log to console in development
  if (config.logToConsole) {
    console.error('[Error Reporting]', errorData);
  }
  
  // Prepare error data for reporting
  const errorInfo = {
    timestamp: new Date().toISOString(),
    url: typeof window !== 'undefined' ? window.location.href : '',
    userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : '',
    ...errorData,
  };
  
  // Track error with analytics
  analyticsService.trackError(
    errorInfo.type || 'error',
    errorInfo.message || 'Unknown error',
    errorInfo.source || 'app'
  );
  
  // In a real application, you would send this to your error reporting service
  // Example: sendToErrorReportingService(errorInfo);
};

/**
 * Report an API error
 * @param {Error} error - Error object
 * @param {Object} requestInfo - Request information
 */
export const reportApiError = (error, requestInfo = {}) => {
  const { url, method, status, data } = requestInfo;
  
  reportError({
    type: 'api_error',
    message: error?.message || 'API Error',
    status,
    url,
    method,
    requestData: typeof data === 'object' ? JSON.stringify(data) : data,
    stack: error?.stack,
    originalError: error,
  });
};

/**
 * Report a network error
 * @param {Error} error - Error object
 * @param {string} url - Request URL
 */
export const reportNetworkError = (error, url) => {
  reportError({
    type: 'network_error',
    message: error?.message || 'Network Error',
    url,
    stack: error?.stack,
    originalError: error,
  });
};

/**
 * Report a validation error
 * @param {Object} validationErrors - Validation errors
 * @param {string} formName - Form name
 */
export const reportValidationError = (validationErrors, formName) => {
  reportError({
    type: 'validation_error',
    message: 'Validation Error',
    formName,
    validationErrors,
  });
};

/**
 * Report a feature error
 * @param {string} featureName - Feature name
 * @param {Error} error - Error object
 * @param {Object} context - Additional context
 */
export const reportFeatureError = (featureName, error, context = {}) => {
  reportError({
    type: 'feature_error',
    message: error?.message || `Error in feature: ${featureName}`,
    featureName,
    context,
    stack: error?.stack,
    originalError: error,
  });
};

/**
 * Create an error handler for async functions
 * @param {Function} fn - Async function to wrap
 * @param {Object} options - Error handler options
 * @returns {Function} - Wrapped function with error handling
 */
export const createErrorHandler = (fn, options = {}) => {
  const { context = {}, onError, rethrow = false } = options;
  
  return async (...args) => {
    try {
      return await fn(...args);
    } catch (error) {
      reportError({
        type: 'handled_error',
        message: error?.message || 'Error in async function',
        context,
        functionName: fn.name,
        args: JSON.stringify(args),
        stack: error?.stack,
        originalError: error,
      });
      
      if (onError && typeof onError === 'function') {
        onError(error);
      }
      
      if (rethrow) {
        throw error;
      }
    }
  };
};

/**
 * Disable error reporting
 */
export const disableErrorReporting = () => {
  config.enabled = false;
  
  if (typeof window !== 'undefined') {
    window.removeEventListener('error', handleGlobalError);
    window.removeEventListener('unhandledrejection', handleUnhandledRejection);
  }
  
  console.log('Error reporting disabled');
};

/**
 * Enable error reporting
 */
export const enableErrorReporting = () => {
  config.enabled = true;
  
  if (config.captureUnhandledErrors && typeof window !== 'undefined') {
    window.addEventListener('error', handleGlobalError);
  }
  
  if (config.captureUnhandledRejections && typeof window !== 'undefined') {
    window.addEventListener('unhandledrejection', handleUnhandledRejection);
  }
  
  console.log('Error reporting enabled');
};

// Export all error reporting functions
const errorReportingService = {
  initErrorReporting,
  reportError,
  reportApiError,
  reportNetworkError,
  reportValidationError,
  reportFeatureError,
  createErrorHandler,
  disableErrorReporting,
  enableErrorReporting,
};

export default errorReportingService;