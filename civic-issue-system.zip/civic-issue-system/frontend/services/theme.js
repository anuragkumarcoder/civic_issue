/**
 * Theme service for managing application theme and UI preferences
 */

// Default theme settings
const defaultTheme = {
  mode: 'system', // 'light', 'dark', or 'system'
  fontSize: 'medium', // 'small', 'medium', 'large'
  reducedMotion: false,
  highContrast: false,
};

/**
 * Initialize theme from localStorage or system preference
 * @returns {Object} - Current theme settings
 */
export const initTheme = () => {
  if (typeof window === 'undefined') {
    return defaultTheme;
  }
  
  try {
    // Try to get theme from localStorage
    const storedTheme = localStorage.getItem('theme');
    let theme = storedTheme ? JSON.parse(storedTheme) : { ...defaultTheme };
    
    // Apply theme to document
    applyTheme(theme);
    
    return theme;
  } catch (error) {
    console.error('Failed to initialize theme:', error);
    return defaultTheme;
  }
};

/**
 * Apply theme settings to document
 * @param {Object} theme - Theme settings
 */
export const applyTheme = (theme) => {
  if (typeof window === 'undefined' || !document) {
    return;
  }
  
  try {
    const { mode, fontSize, reducedMotion, highContrast } = theme;
    const root = document.documentElement;
    
    // Apply dark/light mode
    if (mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
    
    // Apply font size
    root.classList.remove('text-sm', 'text-base', 'text-lg');
    switch (fontSize) {
      case 'small':
        root.classList.add('text-sm');
        break;
      case 'large':
        root.classList.add('text-lg');
        break;
      default:
        root.classList.add('text-base');
    }
    
    // Apply reduced motion preference
    if (reducedMotion) {
      root.classList.add('reduce-motion');
    } else {
      root.classList.remove('reduce-motion');
    }
    
    // Apply high contrast preference
    if (highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }
  } catch (error) {
    console.error('Failed to apply theme:', error);
  }
};

/**
 * Save theme settings to localStorage
 * @param {Object} theme - Theme settings
 */
export const saveTheme = (theme) => {
  if (typeof window === 'undefined') {
    return;
  }
  
  try {
    localStorage.setItem('theme', JSON.stringify(theme));
  } catch (error) {
    console.error('Failed to save theme:', error);
  }
};

/**
 * Toggle between light and dark mode
 * @param {Object} currentTheme - Current theme settings
 * @returns {Object} - Updated theme settings
 */
export const toggleThemeMode = (currentTheme) => {
  const newMode = currentTheme.mode === 'light' ? 'dark' : 'light';
  const newTheme = { ...currentTheme, mode: newMode };
  
  applyTheme(newTheme);
  saveTheme(newTheme);
  
  return newTheme;
};

/**
 * Set specific theme mode
 * @param {Object} currentTheme - Current theme settings
 * @param {string} mode - Theme mode ('light', 'dark', or 'system')
 * @returns {Object} - Updated theme settings
 */
export const setThemeMode = (currentTheme, mode) => {
  if (!['light', 'dark', 'system'].includes(mode)) {
    console.error(`Invalid theme mode: ${mode}`);
    return currentTheme;
  }
  
  const newTheme = { ...currentTheme, mode };
  
  applyTheme(newTheme);
  saveTheme(newTheme);
  
  return newTheme;
};

/**
 * Set font size
 * @param {Object} currentTheme - Current theme settings
 * @param {string} fontSize - Font size ('small', 'medium', or 'large')
 * @returns {Object} - Updated theme settings
 */
export const setFontSize = (currentTheme, fontSize) => {
  if (!['small', 'medium', 'large'].includes(fontSize)) {
    console.error(`Invalid font size: ${fontSize}`);
    return currentTheme;
  }
  
  const newTheme = { ...currentTheme, fontSize };
  
  applyTheme(newTheme);
  saveTheme(newTheme);
  
  return newTheme;
};

/**
 * Toggle reduced motion preference
 * @param {Object} currentTheme - Current theme settings
 * @returns {Object} - Updated theme settings
 */
export const toggleReducedMotion = (currentTheme) => {
  const newTheme = { ...currentTheme, reducedMotion: !currentTheme.reducedMotion };
  
  applyTheme(newTheme);
  saveTheme(newTheme);
  
  return newTheme;
};

/**
 * Toggle high contrast preference
 * @param {Object} currentTheme - Current theme settings
 * @returns {Object} - Updated theme settings
 */
export const toggleHighContrast = (currentTheme) => {
  const newTheme = { ...currentTheme, highContrast: !currentTheme.highContrast };
  
  applyTheme(newTheme);
  saveTheme(newTheme);
  
  return newTheme;
};

/**
 * Reset theme to default settings
 * @returns {Object} - Default theme settings
 */
export const resetTheme = () => {
  applyTheme(defaultTheme);
  saveTheme(defaultTheme);
  
  return { ...defaultTheme };
};

/**
 * Get system color scheme preference
 * @returns {string} - 'dark' or 'light'
 */
export const getSystemTheme = () => {
  if (typeof window === 'undefined') {
    return 'light';
  }
  
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};

/**
 * Setup listener for system theme changes
 * @param {Function} callback - Callback function when system theme changes
 * @returns {Function} - Cleanup function to remove listener
 */
export const listenForSystemThemeChanges = (callback) => {
  if (typeof window === 'undefined') {
    return () => {};
  }
  
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  
  const listener = (e) => {
    callback(e.matches ? 'dark' : 'light');
  };
  
  // Add listener based on browser support
  if (mediaQuery.addEventListener) {
    mediaQuery.addEventListener('change', listener);
  } else {
    // Fallback for older browsers
    mediaQuery.addListener(listener);
  }
  
  // Return cleanup function
  return () => {
    if (mediaQuery.removeEventListener) {
      mediaQuery.removeEventListener('change', listener);
    } else {
      // Fallback for older browsers
      mediaQuery.removeListener(listener);
    }
  };
};

// Export all theme-related functions
const themeService = {
  initTheme,
  applyTheme,
  saveTheme,
  toggleThemeMode,
  setThemeMode,
  setFontSize,
  toggleReducedMotion,
  toggleHighContrast,
  resetTheme,
  getSystemTheme,
  listenForSystemThemeChanges,
};

export default themeService;