/**
 * Storage service for handling localStorage and sessionStorage
 */

/**
 * Check if window and storage are available
 * @returns {boolean} - Whether storage is available
 */
const isStorageAvailable = (type = 'localStorage') => {
  if (typeof window === 'undefined') {
    return false;
  }
  
  try {
    const storage = window[type];
    const testKey = '__storage_test__';
    storage.setItem(testKey, testKey);
    storage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
};

/**
 * Local storage service
 */
export const localStorageService = {
  /**
   * Get an item from localStorage
   * @param {string} key - Storage key
   * @param {*} defaultValue - Default value if key doesn't exist
   * @returns {*} - Stored value or default value
   */
  get: (key, defaultValue = null) => {
    if (!isStorageAvailable('localStorage')) {
      return defaultValue;
    }
    
    try {
      const item = window.localStorage.getItem(key);
      if (item === null) {
        return defaultValue;
      }
      
      try {
        // Try to parse as JSON
        return JSON.parse(item);
      } catch {
        // If not valid JSON, return as string
        return item;
      }
    } catch (error) {
      console.error(`Error getting item from localStorage: ${key}`, error);
      return defaultValue;
    }
  },
  
  /**
   * Set an item in localStorage
   * @param {string} key - Storage key
   * @param {*} value - Value to store
   * @returns {boolean} - Whether operation was successful
   */
  set: (key, value) => {
    if (!isStorageAvailable('localStorage')) {
      return false;
    }
    
    try {
      const valueToStore = typeof value === 'object' ? JSON.stringify(value) : value;
      window.localStorage.setItem(key, valueToStore);
      return true;
    } catch (error) {
      console.error(`Error setting item in localStorage: ${key}`, error);
      return false;
    }
  },
  
  /**
   * Remove an item from localStorage
   * @param {string} key - Storage key
   * @returns {boolean} - Whether operation was successful
   */
  remove: (key) => {
    if (!isStorageAvailable('localStorage')) {
      return false;
    }
    
    try {
      window.localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error(`Error removing item from localStorage: ${key}`, error);
      return false;
    }
  },
  
  /**
   * Clear all items from localStorage
   * @returns {boolean} - Whether operation was successful
   */
  clear: () => {
    if (!isStorageAvailable('localStorage')) {
      return false;
    }
    
    try {
      window.localStorage.clear();
      return true;
    } catch (error) {
      console.error('Error clearing localStorage', error);
      return false;
    }
  },
  
  /**
   * Get all keys from localStorage
   * @returns {Array} - Array of keys
   */
  keys: () => {
    if (!isStorageAvailable('localStorage')) {
      return [];
    }
    
    try {
      return Object.keys(window.localStorage);
    } catch (error) {
      console.error('Error getting keys from localStorage', error);
      return [];
    }
  },
};

/**
 * Session storage service
 */
export const sessionStorageService = {
  /**
   * Get an item from sessionStorage
   * @param {string} key - Storage key
   * @param {*} defaultValue - Default value if key doesn't exist
   * @returns {*} - Stored value or default value
   */
  get: (key, defaultValue = null) => {
    if (!isStorageAvailable('sessionStorage')) {
      return defaultValue;
    }
    
    try {
      const item = window.sessionStorage.getItem(key);
      if (item === null) {
        return defaultValue;
      }
      
      try {
        // Try to parse as JSON
        return JSON.parse(item);
      } catch {
        // If not valid JSON, return as string
        return item;
      }
    } catch (error) {
      console.error(`Error getting item from sessionStorage: ${key}`, error);
      return defaultValue;
    }
  },
  
  /**
   * Set an item in sessionStorage
   * @param {string} key - Storage key
   * @param {*} value - Value to store
   * @returns {boolean} - Whether operation was successful
   */
  set: (key, value) => {
    if (!isStorageAvailable('sessionStorage')) {
      return false;
    }
    
    try {
      const valueToStore = typeof value === 'object' ? JSON.stringify(value) : value;
      window.sessionStorage.setItem(key, valueToStore);
      return true;
    } catch (error) {
      console.error(`Error setting item in sessionStorage: ${key}`, error);
      return false;
    }
  },
  
  /**
   * Remove an item from sessionStorage
   * @param {string} key - Storage key
   * @returns {boolean} - Whether operation was successful
   */
  remove: (key) => {
    if (!isStorageAvailable('sessionStorage')) {
      return false;
    }
    
    try {
      window.sessionStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error(`Error removing item from sessionStorage: ${key}`, error);
      return false;
    }
  },
  
  /**
   * Clear all items from sessionStorage
   * @returns {boolean} - Whether operation was successful
   */
  clear: () => {
    if (!isStorageAvailable('sessionStorage')) {
      return false;
    }
    
    try {
      window.sessionStorage.clear();
      return true;
    } catch (error) {
      console.error('Error clearing sessionStorage', error);
      return false;
    }
  },
  
  /**
   * Get all keys from sessionStorage
   * @returns {Array} - Array of keys
   */
  keys: () => {
    if (!isStorageAvailable('sessionStorage')) {
      return [];
    }
    
    try {
      return Object.keys(window.sessionStorage);
    } catch (error) {
      console.error('Error getting keys from sessionStorage', error);
      return [];
    }
  },
};

/**
 * Cookie service
 */
export const cookieService = {
  /**
   * Get a cookie by name
   * @param {string} name - Cookie name
   * @returns {string|null} - Cookie value or null if not found
   */
  get: (name) => {
    if (typeof window === 'undefined' || !document) {
      return null;
    }
    
    try {
      const cookies = document.cookie.split('; ');
      const cookie = cookies.find(c => c.startsWith(`${name}=`));
      return cookie ? cookie.split('=')[1] : null;
    } catch (error) {
      console.error(`Error getting cookie: ${name}`, error);
      return null;
    }
  },
  
  /**
   * Set a cookie
   * @param {string} name - Cookie name
   * @param {string} value - Cookie value
   * @param {Object} options - Cookie options
   * @returns {boolean} - Whether operation was successful
   */
  set: (name, value, options = {}) => {
    if (typeof window === 'undefined' || !document) {
      return false;
    }
    
    try {
      const { expires, path, domain, secure, sameSite } = options;
      
      let cookieString = `${name}=${value}`;
      
      if (expires) {
        if (typeof expires === 'number') {
          // Expires in days
          const date = new Date();
          date.setTime(date.getTime() + (expires * 24 * 60 * 60 * 1000));
          cookieString += `; expires=${date.toUTCString()}`;
        } else if (expires instanceof Date) {
          cookieString += `; expires=${expires.toUTCString()}`;
        }
      }
      
      if (path) cookieString += `; path=${path}`;
      if (domain) cookieString += `; domain=${domain}`;
      if (secure) cookieString += '; secure';
      if (sameSite) cookieString += `; samesite=${sameSite}`;
      
      document.cookie = cookieString;
      return true;
    } catch (error) {
      console.error(`Error setting cookie: ${name}`, error);
      return false;
    }
  },
  
  /**
   * Remove a cookie
   * @param {string} name - Cookie name
   * @param {Object} options - Cookie options
   * @returns {boolean} - Whether operation was successful
   */
  remove: (name, options = {}) => {
    if (typeof window === 'undefined' || !document) {
      return false;
    }
    
    try {
      // Set expiration to past date to remove cookie
      const { path, domain } = options;
      let cookieString = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
      
      if (path) cookieString += `; path=${path}`;
      if (domain) cookieString += `; domain=${domain}`;
      
      document.cookie = cookieString;
      return true;
    } catch (error) {
      console.error(`Error removing cookie: ${name}`, error);
      return false;
    }
  },
  
  /**
   * Get all cookies as an object
   * @returns {Object} - Object with all cookies
   */
  getAll: () => {
    if (typeof window === 'undefined' || !document) {
      return {};
    }
    
    try {
      return document.cookie.split('; ').reduce((cookies, cookie) => {
        if (cookie) {
          const [name, value] = cookie.split('=');
          cookies[name] = value;
        }
        return cookies;
      }, {});
    } catch (error) {
      console.error('Error getting all cookies', error);
      return {};
    }
  },
};

// Export all storage services
const storageService = {
  local: localStorageService,
  session: sessionStorageService,
  cookie: cookieService,
  isStorageAvailable,
};

export default storageService;