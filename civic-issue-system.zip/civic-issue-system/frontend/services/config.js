/**
 * Configuration service for managing application settings and environment variables
 */

// Default configuration
const defaultConfig = {
  // API settings
  api: {
    baseUrl: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api',
    timeout: 30000, // 30 seconds
    retryAttempts: 3,
    retryDelay: 1000, // 1 second
  },
  
  // Authentication settings
  auth: {
    tokenKey: 'token',
    refreshTokenKey: 'refreshToken',
    tokenExpiry: 60 * 60 * 1000, // 1 hour
    refreshTokenExpiry: 7 * 24 * 60 * 60 * 1000, // 7 days
  },
  
  // Feature flags
  features: {
    darkMode: true,
    notifications: true,
    maps: true,
    fileUploads: true,
    comments: true,
    analytics: process.env.NEXT_PUBLIC_ENABLE_ANALYTICS === 'true',
    errorReporting: process.env.NEXT_PUBLIC_ENABLE_ERROR_REPORTING === 'true',
  },
  
  // UI settings
  ui: {
    defaultTheme: 'light',
    defaultLanguage: 'en',
    itemsPerPage: 10,
    maxUploadSize: 5 * 1024 * 1024, // 5MB
    supportedImageTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    supportedFileTypes: [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'application/pdf', 'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain', 'text/csv'
    ],
  },
  
  // External services
  services: {
    maps: {
      provider: 'openstreetmap',
      apiKey: process.env.NEXT_PUBLIC_MAPS_API_KEY || '',
      defaultCenter: { lat: 40.7128, lng: -74.0060 }, // New York
      defaultZoom: 12,
    },
    analytics: {
      provider: process.env.NEXT_PUBLIC_ANALYTICS_PROVIDER || 'none',
      trackingId: process.env.NEXT_PUBLIC_ANALYTICS_ID || '',
    },
    errorReporting: {
      provider: process.env.NEXT_PUBLIC_ERROR_REPORTING_PROVIDER || 'none',
      dsn: process.env.NEXT_PUBLIC_ERROR_REPORTING_DSN || '',
      environment: process.env.NEXT_PUBLIC_ENVIRONMENT || 'development',
    },
  },
  
  // Development settings
  development: {
    debug: process.env.NEXT_PUBLIC_DEBUG === 'true',
    mockApi: process.env.NEXT_PUBLIC_MOCK_API === 'true',
    logLevel: process.env.NEXT_PUBLIC_LOG_LEVEL || 'error',
  },
};

// Current configuration
let currentConfig = { ...defaultConfig };

/**
 * Initialize configuration
 * @param {Object} customConfig - Custom configuration to merge
 * @returns {Object} - Merged configuration
 */
export const initialize = (customConfig = {}) => {
  try {
    // Merge custom configuration with default
    currentConfig = mergeConfigs(defaultConfig, customConfig);
    
    // Apply environment-specific overrides
    applyEnvironmentOverrides();
    
    return currentConfig;
  } catch (error) {
    console.error('Error initializing configuration:', error);
    return defaultConfig;
  }
};

/**
 * Merge configurations recursively
 * @param {Object} target - Target configuration
 * @param {Object} source - Source configuration to merge
 * @returns {Object} - Merged configuration
 */
const mergeConfigs = (target, source) => {
  const result = { ...target };
  
  for (const key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      if (source[key] instanceof Object && key in target) {
        result[key] = mergeConfigs(target[key], source[key]);
      } else {
        result[key] = source[key];
      }
    }
  }
  
  return result;
};

/**
 * Apply environment-specific configuration overrides
 */
const applyEnvironmentOverrides = () => {
  const environment = process.env.NEXT_PUBLIC_ENVIRONMENT || 'development';
  
  // Apply environment-specific settings
  switch (environment) {
    case 'production':
      // Production overrides
      currentConfig.development.debug = false;
      currentConfig.development.mockApi = false;
      break;
      
    case 'staging':
      // Staging overrides
      currentConfig.development.debug = true;
      break;
      
    case 'development':
    default:
      // Development overrides
      currentConfig.development.debug = true;
      break;
  }
};

/**
 * Get entire configuration
 * @returns {Object} - Current configuration
 */
export const getConfig = () => {
  return { ...currentConfig };
};

/**
 * Get specific configuration value
 * @param {string} path - Configuration path (e.g., 'api.baseUrl')
 * @param {*} defaultValue - Default value if path not found
 * @returns {*} - Configuration value
 */
export const get = (path, defaultValue = null) => {
  try {
    const keys = path.split('.');
    let value = { ...currentConfig };
    
    for (const key of keys) {
      if (value[key] === undefined) {
        return defaultValue;
      }
      
      value = value[key];
    }
    
    return value;
  } catch (error) {
    console.error(`Error getting config value for ${path}:`, error);
    return defaultValue;
  }
};

/**
 * Set specific configuration value
 * @param {string} path - Configuration path (e.g., 'api.baseUrl')
 * @param {*} value - Value to set
 * @returns {boolean} - Whether set was successful
 */
export const set = (path, value) => {
  try {
    const keys = path.split('.');
    const lastKey = keys.pop();
    
    let current = currentConfig;
    
    // Navigate to the parent object
    for (const key of keys) {
      if (current[key] === undefined) {
        current[key] = {};
      }
      
      if (typeof current[key] !== 'object') {
        throw new Error(`Cannot set property ${path} because ${key} is not an object`);
      }
      
      current = current[key];
    }
    
    // Set the value
    current[lastKey] = value;
    
    return true;
  } catch (error) {
    console.error(`Error setting config value for ${path}:`, error);
    return false;
  }
};

/**
 * Reset configuration to default
 * @returns {Object} - Default configuration
 */
export const resetToDefault = () => {
  currentConfig = { ...defaultConfig };
  applyEnvironmentOverrides();
  
  return currentConfig;
};

/**
 * Check if a feature is enabled
 * @param {string} featureName - Feature name
 * @returns {boolean} - Whether feature is enabled
 */
export const isFeatureEnabled = (featureName) => {
  return get(`features.${featureName}`, false);
};

/**
 * Get all feature flags
 * @returns {Object} - Feature flags
 */
export const getFeatureFlags = () => {
  return get('features', {});
};

/**
 * Set feature flag
 * @param {string} featureName - Feature name
 * @param {boolean} enabled - Whether feature is enabled
 * @returns {boolean} - Whether set was successful
 */
export const setFeatureFlag = (featureName, enabled) => {
  return set(`features.${featureName}`, enabled);
};

/**
 * Get environment name
 * @returns {string} - Environment name
 */
export const getEnvironment = () => {
  return process.env.NEXT_PUBLIC_ENVIRONMENT || 'development';
};

/**
 * Check if running in development environment
 * @returns {boolean} - Whether in development
 */
export const isDevelopment = () => {
  return getEnvironment() === 'development';
};

/**
 * Check if running in production environment
 * @returns {boolean} - Whether in production
 */
export const isProduction = () => {
  return getEnvironment() === 'production';
};

/**
 * Check if running in staging environment
 * @returns {boolean} - Whether in staging
 */
export const isStaging = () => {
  return getEnvironment() === 'staging';
};

/**
 * Check if debug mode is enabled
 * @returns {boolean} - Whether debug mode is enabled
 */
export const isDebugEnabled = () => {
  return get('development.debug', false);
};

// Export all configuration-related functions
const configService = {
  initialize,
  getConfig,
  get,
  set,
  resetToDefault,
  isFeatureEnabled,
  getFeatureFlags,
  setFeatureFlag,
  getEnvironment,
  isDevelopment,
  isProduction,
  isStaging,
  isDebugEnabled,
};

export default configService;